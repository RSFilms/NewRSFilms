<?php
require_once 'config.php';

if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Get filter parameters
$status_filter = $_GET['status'] ?? '';

// Build query
$where = "user_id = ?";
$params = [$user_id];
$types = 'i';

if (!empty($status_filter)) {
    $where .= " AND status = ?";
    $params[] = $status_filter;
    $types .= 's';
}

$query = "SELECT p.*, s.title as service_title 
          FROM projects p 
          LEFT JOIN services s ON p.service_id = s.id 
          WHERE $where 
          ORDER BY p.created_at DESC";

$stmt = $conn->prepare($query);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$projects = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en" data-mdb-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Projects - <?php echo SITE_NAME; ?></title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.4.2/mdb.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root { --primary-color: #1976d2; }
        .page-header { background: linear-gradient(135deg, var(--primary-color) 0%, #1565c0 100%); color: white; padding: 60px 0; }
        .project-card { transition: transform 0.3s, box-shadow 0.3s; cursor: pointer; }
        .project-card:hover { transform: translateY(-5px); box-shadow: 0 10px 30px rgba(0,0,0,0.15); }
        .status-badge { font-size: 0.85rem; padding: 6px 12px; }
        [data-mdb-theme="dark"] .page-header { background: linear-gradient(135deg, #0d47a1 0%, #01579b 100%); }
        @media (max-width: 768px) { .page-header { padding: 40px 0; } }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light shadow-sm sticky-top">
        <div class="container">
            <a class="navbar-brand fw-bold" href="index.php">
                <i class="fas fa-film me-2"></i><?php echo SITE_NAME; ?>
            </a>
            <button class="navbar-toggler" type="button" data-mdb-toggle="collapse" data-mdb-target="#navbarNav">
                <i class="fas fa-bars"></i>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto align-items-center">
                    <li class="nav-item"><a class="nav-link" href="dashboard.php">Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link active" href="my-projects.php">My Projects</a></li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-mdb-toggle="dropdown">
                            <i class="fas fa-user-circle"></i> <?php echo htmlspecialchars($_SESSION['user_name']); ?>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="profile.php">Profile</a></li>
                            <li><a class="dropdown-item" href="logout.php">Logout</a></li>
                        </ul>
                    </li>
                    <li class="nav-item ms-2">
                        <button class="btn btn-sm btn-outline-secondary" id="theme-toggle">
                            <i class="fas fa-moon"></i>
                        </button>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="page-header">
        <div class="container">
            <h1 class="fw-bold mb-2">My Projects</h1>
            <p class="mb-0">Track and manage all your projects</p>
        </div>
    </div>

    <div class="container my-5">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div class="btn-group" role="group">
                <a href="my-projects.php" class="btn btn-sm <?php echo empty($status_filter) ? 'btn-primary' : 'btn-outline-primary'; ?>">All</a>
                <a href="?status=pending" class="btn btn-sm <?php echo $status_filter === 'pending' ? 'btn-primary' : 'btn-outline-primary'; ?>">Pending</a>
                <a href="?status=in_progress" class="btn btn-sm <?php echo $status_filter === 'in_progress' ? 'btn-primary' : 'btn-outline-primary'; ?>">In Progress</a>
                <a href="?status=completed" class="btn btn-sm <?php echo $status_filter === 'completed' ? 'btn-primary' : 'btn-outline-primary'; ?>">Completed</a>
            </div>
            <a href="submit-project.php" class="btn btn-primary">
                <i class="fas fa-plus me-2"></i>New Project
            </a>
        </div>

        <div class="row">
            <?php if ($projects->num_rows > 0): ?>
                <?php while ($project = $projects->fetch_assoc()): 
                    $badge_class = ['pending' => 'warning', 'in_progress' => 'info', 'review' => 'primary', 'completed' => 'success', 'cancelled' => 'danger'];
                    $status_class = $badge_class[$project['status']] ?? 'secondary';
                ?>
                <div class="col-md-6 col-lg-4 mb-4">
                    <div class="card project-card h-100" onclick="window.location.href='project-detail.php?id=<?php echo $project['id']; ?>'">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-start mb-3">
                                <h5 class="card-title fw-bold mb-0"><?php echo htmlspecialchars($project['title']); ?></h5>
                                <span class="badge bg-<?php echo $status_class; ?> status-badge">
                                    <?php echo ucfirst(str_replace('_', ' ', $project['status'])); ?>
                                </span>
                            </div>
                            
                            <p class="text-muted small mb-2">
                                <i class="fas fa-briefcase me-2"></i><?php echo htmlspecialchars($project['service_title'] ?? 'N/A'); ?>
                            </p>
                            
                            <p class="card-text text-muted"><?php echo substr(htmlspecialchars($project['description']), 0, 100) . '...'; ?></p>
                            
                            <div class="d-flex justify-content-between align-items-center mt-3">
                                <small class="text-muted">
                                    <i class="fas fa-calendar me-1"></i>
                                    <?php echo date('M d, Y', strtotime($project['created_at'])); ?>
                                </small>
                                <div class="fw-bold text-primary">₹<?php echo number_format($project['total_cost'], 0); ?></div>
                            </div>
                            
                            <?php if ($project['balance'] > 0): ?>
                            <div class="mt-2">
                                <small class="text-danger">
                                    <i class="fas fa-exclamation-circle me-1"></i>Balance: ₹<?php echo number_format($project['balance'], 0); ?>
                                </small>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div class="col-12 text-center py-5">
                    <i class="fas fa-folder-open fa-4x text-muted mb-3"></i>
                    <h3>No projects found</h3>
                    <p class="text-muted mb-4">Start your first project with us today!</p>
                    <a href="submit-project.php" class="btn btn-primary btn-lg">
                        <i class="fas fa-plus me-2"></i>Submit Project
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.4.2/mdb.min.js"></script>
    <script>
        const themeToggle = document.getElementById('theme-toggle');
        const htmlElement = document.documentElement;
        const savedTheme = localStorage.getItem('theme') || 'light';
        htmlElement.setAttribute('data-mdb-theme', savedTheme);
        themeToggle.querySelector('i').className = savedTheme === 'light' ? 'fas fa-moon' : 'fas fa-sun';
        themeToggle.addEventListener('click', () => {
            const currentTheme = htmlElement.getAttribute('data-mdb-theme');
            const newTheme = currentTheme === 'light' ? 'dark' : 'light';
            htmlElement.setAttribute('data-mdb-theme', newTheme);
            localStorage.setItem('theme', newTheme);
            themeToggle.querySelector('i').className = newTheme === 'light' ? 'fas fa-moon' : 'fas fa-sun';
        });
    </script>
</body>
</html>
