# R.S Films Group - Digital Management Website

A comprehensive digital management website for R.S Films Group with robust user and admin features for managing audio/video production services, projects, and finances.

## 🎯 Features

### User Side (Client Features)
- **Authentication System**
  - Secure signup/login with password_hash and password_verify
  - Forgot password & reset functionality
  - Session-based authentication
  
- **Landing & Service Pages**
  - Responsive landing page with hero section
  - Service listing with filters (category, price range, search)
  - Service detail pages with pricing and features
  - Portfolio showcase
  
- **Dashboard & Project Management**
  - User dashboard with statistics
  - Project submission with file upload (up to 100MB)
  - Project metadata (ISRC, release dates, artist info)
  - Track project status and progress
  - Download final masters
  
- **Finance Ledger**
  - View all transactions
  - Payment history
  - Outstanding balance tracking
  - Project cost breakdown
  
- **Support & Contact**
  - Contact form
  - Support ticket system
  - FAQ page

### Admin Side (Backend Features)
- **Admin Authentication**
  - Secure admin login
  - Role-based access (Super Admin, Editor)
  
- **Dashboard**
  - Statistics overview
  - Recent projects and users
  - Revenue tracking
  
- **Project Management**
  - View all client projects
  - Update project status and costs
  - Access uploaded files
  - Set project milestones
  
- **User Management**
  - View all registered users
  - Block/unblock users
  - View user project history
  
- **Service Management**
  - Add/edit/delete services
  - Set pricing models
  - Manage service categories
  
- **Finance Management**
  - View all transactions
  - Track payments and invoices
  - Outstanding payment reports
  
- **Coupon System**
  - Create discount codes
  - Set expiry and usage limits
  - Flat or percentage discounts
  
- **Support Management**
  - Manage support tickets
  - Respond to queries
  - Manage FAQ

## 🛠 Tech Stack

- **Frontend**: PHP, HTML5, CSS3, JavaScript
- **UI Framework**: MDBootstrap 6.4.2
- **Icons**: Font Awesome 6.4.0
- **Backend**: PHP 7.4+
- **Database**: MySQL 5.7+
- **Server**: Apache (XAMPP)

## 📦 Installation

### Prerequisites
- XAMPP (or any PHP 7.4+ with MySQL server)
- Web browser

### Step 1: Setup Files
1. Download/extract the project to your XAMPP htdocs folder:
   ```
   C:\xampp\htdocs\R.S Films Group\
   ```

### Step 2: Create Database
1. Open phpMyAdmin (http://localhost/phpmyadmin)
2. Click "Import" tab
3. Select the `database.sql` file
4. Click "Go" to import

   **OR** Run the SQL commands from `database.sql` in the SQL tab

### Step 3: Configure Database Connection
1. Open `config.php`
2. Update database credentials if needed:
   ```php
   define('DB_HOST', 'localhost');
   define('DB_USER', 'root');
   define('DB_PASS', '');
   define('DB_NAME', 'rs_films_group');
   ```

### Step 4: Set Permissions
Ensure the `uploads/` folder has write permissions:
```
chmod 777 uploads/
```

### Step 5: Access the Website
- **User Site**: http://localhost/R.S%20Films%20Group/
- **Admin Panel**: http://localhost/R.S%20Films%20Group/admin/

## 🔐 Default Credentials

### Admin Login
- **Email**: admin@rsfilmsgroup.com
- **Password**: admin123
- ⚠️ **IMPORTANT**: Change this password immediately after first login!

## 📱 Design Features

### Mobile View (Native App Experience)
- Material Design inspired UI
- AppBar with logo and menu
- Bottom navigation bar (Home, Services, Projects, Profile)
- Full-width cards with large touch-friendly buttons
- Native-style transitions
- Vertical scrollable lists

### Desktop View (Professional Website)
- Professional navbar with navigation links
- Sidebar navigation in dashboards
- Grid layout for services (3-4 items per row)
- Modern client management dashboard
- Professional typography and spacing
- Fully responsive scaling

### Theme Support
- Dark and light theme toggle
- Theme preference saved in localStorage
- Consistent theme across all pages

## 📂 Project Structure

```
R.S Films Group/
├── admin/                 # Admin panel
│   ├── config.php        # Admin configuration
│   ├── index.php         # Admin dashboard
│   ├── login.php         # Admin login
│   ├── projects.php      # Project management
│   ├── users.php         # User management
│   └── ...
├── uploads/              # File upload directory
│   ├── projects/         # Project files
│   └── services/         # Service images
├── config.php            # Main configuration
├── database.sql          # Database schema
├── index.php             # Landing page
├── login.php             # User login
├── signup.php            # User registration
├── dashboard.php         # User dashboard
├── services.php          # Service listing
├── submit-project.php    # Project submission
├── my-projects.php       # User projects
├── finance-ledger.php    # Finance tracking
├── profile.php           # User profile
├── contact.php           # Contact page
└── README.md             # This file
```

## 🔒 Security Features

- **Password Security**: Using PHP password_hash() and password_verify()
- **Session Management**: Secure session handling with timeouts
- **Input Sanitization**: All user inputs sanitized
- **SQL Injection Prevention**: Prepared statements
- **CSRF Protection**: Token-based form protection
- **File Upload Validation**: Type and size restrictions
- **Role-Based Access**: Separate user and admin authentication

## 🚀 Usage

### For Users
1. Register an account via signup page
2. Login with your credentials
3. Browse services and submit projects
4. Upload project files (audio/video)
5. Track project progress in dashboard
6. View finance ledger for payments
7. Download final masters when completed

### For Admins
1. Login to admin panel
2. View dashboard statistics
3. Manage projects (update status, costs)
4. Manage users (block/unblock)
5. Create and manage services
6. Track finances and payments
7. Respond to support tickets
8. Generate reports

## 📊 Database Schema

### Main Tables
- `users` - Client accounts
- `admins` - Admin accounts
- `services` - Service offerings
- `projects` - Client projects
- `project_files` - Uploaded files
- `project_metadata` - ISRC, release info
- `finance_ledger` - Transactions
- `coupons` - Discount codes
- `support_tickets` - Support system
- `testimonials` - Client testimonials
- `faqs` - FAQ content
- `settings` - Site configuration

## 🎨 Customization

### Change Site Name
Edit `config.php`:
```php
define('SITE_NAME', 'Your Company Name');
```

### Update Colors
Edit CSS variables in any page:
```css
:root {
    --primary-color: #1976d2; /* Change to your brand color */
}
```

### Configure Payment Gateway
Update settings in admin panel or directly in `settings` table

### Email Configuration
For production, configure SMTP settings in `config.php` for password reset emails

## 📝 Important Notes

1. **File Uploads**: Maximum file size is 100MB (configurable in `config.php`)
2. **Session Timeout**: Default is PHP's session timeout (configurable)
3. **Error Display**: Set `display_errors` to 0 in production
4. **HTTPS**: Use HTTPS in production for security
5. **Backup**: Regular database backups recommended
6. **Permissions**: Ensure proper file permissions on server

## 🐛 Troubleshooting

### Database Connection Error
- Check database credentials in `config.php`
- Ensure MySQL service is running
- Verify database exists

### File Upload Issues
- Check `uploads/` folder permissions (777)
- Verify `upload_max_filesize` and `post_max_size` in php.ini
- Check `MAX_FILE_SIZE` constant in `config.php`

### Session Issues
- Clear browser cookies
- Check session path in php.ini
- Verify session_start() is called

### Theme Not Saving
- Check browser localStorage is enabled
- Clear browser cache

## 📞 Support

For issues or questions:
- Email: contact@rsfilmsgroup.com
- Phone: +91 1234567890

## 📄 License

This project is proprietary software for R.S Films Group.

## 🔄 Version

**Version**: 1.0.0  
**Last Updated**: 2024

---

**Developed with ❤️ for R.S Films Group**
