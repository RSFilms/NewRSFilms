<?php
require_once 'config.php';

if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Get user statistics
$projects_query = "SELECT COUNT(*) as total, 
                   SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending,
                   SUM(CASE WHEN status = 'in_progress' THEN 1 ELSE 0 END) as in_progress,
                   SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed
                   FROM projects WHERE user_id = ?";
$stmt = $conn->prepare($projects_query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$projects_stats = $stmt->get_result()->fetch_assoc();

// Get financial summary
$finance_query = "SELECT 
                  COALESCE(SUM(total_cost), 0) as total_billed,
                  COALESCE(SUM(paid_amount), 0) as total_paid,
                  COALESCE(SUM(balance), 0) as total_due
                  FROM projects WHERE user_id = ?";
$stmt = $conn->prepare($finance_query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$finance_stats = $stmt->get_result()->fetch_assoc();

// Get recent projects
$recent_projects_query = "SELECT p.*, s.title as service_title 
                          FROM projects p 
                          LEFT JOIN services s ON p.service_id = s.id 
                          WHERE p.user_id = ? 
                          ORDER BY p.created_at DESC LIMIT 5";
$stmt = $conn->prepare($recent_projects_query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$recent_projects = $stmt->get_result();

// Get recent transactions
$transactions_query = "SELECT * FROM finance_ledger WHERE user_id = ? ORDER BY transaction_date DESC LIMIT 5";
$stmt = $conn->prepare($transactions_query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$recent_transactions = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en" data-mdb-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - <?php echo SITE_NAME; ?></title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.4.2/mdb.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: #1976d2;
        }
        
        .dashboard-header {
            background: linear-gradient(135deg, var(--primary-color) 0%, #1565c0 100%);
            color: white;
            padding: 40px 0;
        }
        
        .stat-card {
            border-left: 4px solid var(--primary-color);
            transition: transform 0.3s;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
        }
        
        .stat-number {
            font-size: 2rem;
            font-weight: 700;
        }
        
        .status-badge {
            font-size: 0.75rem;
            padding: 4px 8px;
        }
        
        .mobile-bottom-nav {
            display: none;
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: white;
            box-shadow: 0 -2px 10px rgba(0,0,0,0.1);
            z-index: 1000;
            padding: 10px 0;
        }
        
        .mobile-nav-item {
            text-align: center;
            color: #666;
            text-decoration: none;
            font-size: 0.75rem;
        }
        
        .mobile-nav-item i {
            font-size: 1.5rem;
            display: block;
            margin-bottom: 5px;
        }
        
        .mobile-nav-item.active {
            color: var(--primary-color);
        }
        
        [data-mdb-theme="dark"] .dashboard-header {
            background: linear-gradient(135deg, #0d47a1 0%, #01579b 100%);
        }
        
        [data-mdb-theme="dark"] .mobile-bottom-nav {
            background: #1e1e1e;
            border-top: 1px solid #333;
        }
        
        @media (max-width: 768px) {
            .mobile-bottom-nav {
                display: flex;
            }
            
            body {
                padding-bottom: 70px;
            }
            
            .dashboard-header {
                padding: 30px 0;
            }
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light shadow-sm sticky-top">
        <div class="container">
            <a class="navbar-brand fw-bold" href="index.php">
                <i class="fas fa-film me-2"></i><?php echo SITE_NAME; ?>
            </a>
            
            <button class="navbar-toggler" type="button" data-mdb-toggle="collapse" data-mdb-target="#navbarNav">
                <i class="fas fa-bars"></i>
            </button>
            
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto align-items-center">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="services.php">Services</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="dashboard.php">Dashboard</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-mdb-toggle="dropdown">
                            <i class="fas fa-user-circle"></i> <?php echo htmlspecialchars($_SESSION['user_name']); ?>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="profile.php"><i class="fas fa-user me-2"></i>Profile</a></li>
                            <li><a class="dropdown-item" href="my-projects.php"><i class="fas fa-folder me-2"></i>My Projects</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                        </ul>
                    </li>
                    <li class="nav-item ms-2">
                        <button class="btn btn-sm btn-outline-secondary" id="theme-toggle">
                            <i class="fas fa-moon"></i>
                        </button>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Dashboard Header -->
    <div class="dashboard-header">
        <div class="container">
            <h1 class="fw-bold mb-2">Welcome back, <?php echo htmlspecialchars($_SESSION['user_name']); ?>!</h1>
            <p class="mb-0">Here's an overview of your projects and activities</p>
        </div>
    </div>

    <!-- Main Content -->
    <div class="container my-5">
        <!-- Statistics Cards -->
        <div class="row mb-4">
            <div class="col-md-3 col-sm-6 mb-3">
                <div class="card stat-card h-100">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <p class="text-muted mb-1">Total Projects</p>
                                <div class="stat-number text-primary"><?php echo $projects_stats['total']; ?></div>
                            </div>
                            <i class="fas fa-folder fa-3x text-primary opacity-50"></i>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3 col-sm-6 mb-3">
                <div class="card stat-card h-100" style="border-left-color: #ffc107;">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <p class="text-muted mb-1">In Progress</p>
                                <div class="stat-number" style="color: #ffc107;"><?php echo $projects_stats['in_progress']; ?></div>
                            </div>
                            <i class="fas fa-spinner fa-3x opacity-50" style="color: #ffc107;"></i>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3 col-sm-6 mb-3">
                <div class="card stat-card h-100" style="border-left-color: #28a745;">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <p class="text-muted mb-1">Completed</p>
                                <div class="stat-number" style="color: #28a745;"><?php echo $projects_stats['completed']; ?></div>
                            </div>
                            <i class="fas fa-check-circle fa-3x opacity-50" style="color: #28a745;"></i>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3 col-sm-6 mb-3">
                <div class="card stat-card h-100" style="border-left-color: #dc3545;">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <p class="text-muted mb-1">Amount Due</p>
                                <div class="stat-number" style="color: #dc3545;">₹<?php echo number_format($finance_stats['total_due'], 0); ?></div>
                            </div>
                            <i class="fas fa-rupee-sign fa-3x opacity-50" style="color: #dc3545;"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="card mb-4">
            <div class="card-body">
                <h5 class="card-title fw-bold mb-3">Quick Actions</h5>
                <div class="row">
                    <div class="col-md-3 col-sm-6 mb-3">
                        <a href="submit-project.php" class="btn btn-primary w-100">
                            <i class="fas fa-plus-circle me-2"></i>New Project
                        </a>
                    </div>
                    <div class="col-md-3 col-sm-6 mb-3">
                        <a href="my-projects.php" class="btn btn-outline-primary w-100">
                            <i class="fas fa-folder-open me-2"></i>View Projects
                        </a>
                    </div>
                    <div class="col-md-3 col-sm-6 mb-3">
                        <a href="finance-ledger.php" class="btn btn-outline-primary w-100">
                            <i class="fas fa-file-invoice me-2"></i>Finance Ledger
                        </a>
                    </div>
                    <div class="col-md-3 col-sm-6 mb-3">
                        <a href="contact.php" class="btn btn-outline-primary w-100">
                            <i class="fas fa-headset me-2"></i>Support
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <!-- Recent Projects -->
            <div class="col-lg-7 mb-4">
                <div class="card h-100">
                    <div class="card-header bg-white">
                        <div class="d-flex justify-content-between align-items-center">
                            <h5 class="mb-0 fw-bold">Recent Projects</h5>
                            <a href="my-projects.php" class="btn btn-sm btn-link">View All</a>
                        </div>
                    </div>
                    <div class="card-body">
                        <?php if ($recent_projects->num_rows > 0): ?>
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>Project</th>
                                            <th>Service</th>
                                            <th>Status</th>
                                            <th>Amount</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php while ($project = $recent_projects->fetch_assoc()): ?>
                                        <tr>
                                            <td>
                                                <a href="project-detail.php?id=<?php echo $project['id']; ?>" class="text-decoration-none">
                                                    <?php echo htmlspecialchars($project['title']); ?>
                                                </a>
                                            </td>
                                            <td><?php echo htmlspecialchars($project['service_title'] ?? 'N/A'); ?></td>
                                            <td>
                                                <?php
                                                $badge_class = [
                                                    'pending' => 'warning',
                                                    'in_progress' => 'info',
                                                    'review' => 'primary',
                                                    'completed' => 'success',
                                                    'cancelled' => 'danger'
                                                ];
                                                $class = $badge_class[$project['status']] ?? 'secondary';
                                                ?>
                                                <span class="badge bg-<?php echo $class; ?> status-badge">
                                                    <?php echo ucfirst($project['status']); ?>
                                                </span>
                                            </td>
                                            <td class="fw-bold">₹<?php echo number_format($project['total_cost'], 0); ?></td>
                                        </tr>
                                        <?php endwhile; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <div class="text-center py-4">
                                <i class="fas fa-folder-open fa-3x text-muted mb-3"></i>
                                <p class="text-muted">No projects yet</p>
                                <a href="submit-project.php" class="btn btn-primary">Create Your First Project</a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Recent Transactions -->
            <div class="col-lg-5 mb-4">
                <div class="card h-100">
                    <div class="card-header bg-white">
                        <div class="d-flex justify-content-between align-items-center">
                            <h5 class="mb-0 fw-bold">Recent Transactions</h5>
                            <a href="finance-ledger.php" class="btn btn-sm btn-link">View All</a>
                        </div>
                    </div>
                    <div class="card-body">
                        <?php if ($recent_transactions->num_rows > 0): ?>
                            <div class="list-group list-group-flush">
                                <?php while ($transaction = $recent_transactions->fetch_assoc()): ?>
                                <div class="list-group-item px-0">
                                    <div class="d-flex justify-content-between align-items-start">
                                        <div>
                                            <h6 class="mb-1"><?php echo htmlspecialchars($transaction['description']); ?></h6>
                                            <small class="text-muted">
                                                <i class="fas fa-calendar me-1"></i>
                                                <?php echo date('M d, Y', strtotime($transaction['transaction_date'])); ?>
                                            </small>
                                        </div>
                                        <div class="text-end">
                                            <div class="fw-bold <?php echo $transaction['transaction_type'] === 'credit' || $transaction['transaction_type'] === 'payment' ? 'text-success' : 'text-danger'; ?>">
                                                <?php echo $transaction['transaction_type'] === 'credit' || $transaction['transaction_type'] === 'payment' ? '+' : '-'; ?>
                                                ₹<?php echo number_format($transaction['amount'], 2); ?>
                                            </div>
                                            <small class="badge bg-<?php echo $transaction['status'] === 'completed' ? 'success' : 'warning'; ?>">
                                                <?php echo ucfirst($transaction['status']); ?>
                                            </small>
                                        </div>
                                    </div>
                                </div>
                                <?php endwhile; ?>
                            </div>
                        <?php else: ?>
                            <div class="text-center py-4">
                                <i class="fas fa-receipt fa-3x text-muted mb-3"></i>
                                <p class="text-muted">No transactions yet</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Mobile Bottom Navigation -->
    <div class="mobile-bottom-nav">
        <div class="container-fluid">
            <div class="row">
                <div class="col-3">
                    <a href="index.php" class="mobile-nav-item d-block">
                        <i class="fas fa-home"></i>
                        <div>Home</div>
                    </a>
                </div>
                <div class="col-3">
                    <a href="services.php" class="mobile-nav-item d-block">
                        <i class="fas fa-th-large"></i>
                        <div>Services</div>
                    </a>
                </div>
                <div class="col-3">
                    <a href="my-projects.php" class="mobile-nav-item d-block">
                        <i class="fas fa-folder"></i>
                        <div>Projects</div>
                    </a>
                </div>
                <div class="col-3">
                    <a href="profile.php" class="mobile-nav-item d-block">
                        <i class="fas fa-user"></i>
                        <div>Profile</div>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.4.2/mdb.min.js"></script>
    <script>
        const themeToggle = document.getElementById('theme-toggle');
        const htmlElement = document.documentElement;
        const savedTheme = localStorage.getItem('theme') || 'light';
        htmlElement.setAttribute('data-mdb-theme', savedTheme);
        updateThemeIcon(savedTheme);
        
        themeToggle.addEventListener('click', () => {
            const currentTheme = htmlElement.getAttribute('data-mdb-theme');
            const newTheme = currentTheme === 'light' ? 'dark' : 'light';
            htmlElement.setAttribute('data-mdb-theme', newTheme);
            localStorage.setItem('theme', newTheme);
            updateThemeIcon(newTheme);
        });
        
        function updateThemeIcon(theme) {
            const icon = themeToggle.querySelector('i');
            icon.className = theme === 'light' ? 'fas fa-moon' : 'fas fa-sun';
        }
    </script>
</body>
</html>
