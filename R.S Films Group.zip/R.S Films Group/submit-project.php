<?php
require_once 'config.php';

if (!isLoggedIn()) {
    header('Location: login.php?redirect=submit-project.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$service_id = $_GET['service_id'] ?? '';
$errors = [];
$success = '';

// Get services for dropdown
$services_result = $conn->query("SELECT id, title FROM services WHERE status = 'active' ORDER BY title");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = sanitize($_POST['title'] ?? '');
    $description = sanitize($_POST['description'] ?? '');
    $project_type = sanitize($_POST['project_type'] ?? '');
    $service_id = sanitize($_POST['service_id'] ?? '');
    $deadline = sanitize($_POST['deadline'] ?? '');
    
    // Metadata fields
    $isrc = sanitize($_POST['isrc'] ?? '');
    $song_title = sanitize($_POST['song_title'] ?? '');
    $artist_name = sanitize($_POST['artist_name'] ?? '');
    $album_name = sanitize($_POST['album_name'] ?? '');
    $release_date = sanitize($_POST['release_date'] ?? '');
    $genre = sanitize($_POST['genre'] ?? '');
    $label = sanitize($_POST['label'] ?? '');
    $additional_info = sanitize($_POST['additional_info'] ?? '');
    
    // Validation
    if (empty($title)) {
        $errors[] = 'Project title is required';
    }
    
    if (empty($description)) {
        $errors[] = 'Project description is required';
    }
    
    if (empty($errors)) {
        $conn->begin_transaction();
        
        try {
            // Insert project
            $stmt = $conn->prepare("INSERT INTO projects (user_id, service_id, title, description, project_type, deadline, status) VALUES (?, ?, ?, ?, ?, ?, 'pending')");
            $stmt->bind_param("iissss", $user_id, $service_id, $title, $description, $project_type, $deadline);
            $stmt->execute();
            $project_id = $conn->insert_id;
            
            // Insert metadata if provided
            if (!empty($isrc) || !empty($song_title)) {
                $stmt = $conn->prepare("INSERT INTO project_metadata (project_id, isrc, song_title, artist_name, album_name, release_date, genre, label, additional_info) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->bind_param("issssssss", $project_id, $isrc, $song_title, $artist_name, $album_name, $release_date, $genre, $label, $additional_info);
                $stmt->execute();
            }
            
            // Handle file uploads
            if (isset($_FILES['project_files']) && !empty($_FILES['project_files']['name'][0])) {
                $upload_dir = UPLOAD_PATH . 'projects/';
                
                foreach ($_FILES['project_files']['name'] as $key => $name) {
                    if ($_FILES['project_files']['error'][$key] === UPLOAD_ERR_OK) {
                        $tmp_name = $_FILES['project_files']['tmp_name'][$key];
                        $file_size = $_FILES['project_files']['size'][$key];
                        
                        // Validate file size
                        if ($file_size > MAX_FILE_SIZE) {
                            $errors[] = "File $name exceeds maximum size of 100MB";
                            continue;
                        }
                        
                        // Generate unique filename
                        $extension = pathinfo($name, PATHINFO_EXTENSION);
                        $new_filename = $project_id . '_' . time() . '_' . uniqid() . '.' . $extension;
                        $file_path = $upload_dir . $new_filename;
                        
                        if (move_uploaded_file($tmp_name, $file_path)) {
                            // Save file info to database
                            $file_type = $_FILES['project_files']['type'][$key];
                            $stmt = $conn->prepare("INSERT INTO project_files (project_id, file_name, original_name, file_path, file_type, file_size, uploaded_by, category) VALUES (?, ?, ?, ?, ?, ?, 'user', 'source')");
                            $stmt->bind_param("issssi", $project_id, $new_filename, $name, $file_path, $file_type, $file_size);
                            $stmt->execute();
                        }
                    }
                }
            }
            
            $conn->commit();
            $success = 'Project submitted successfully! Our team will review it shortly.';
            header('refresh:2;url=my-projects.php');
            
        } catch (Exception $e) {
            $conn->rollback();
            $errors[] = 'Failed to submit project. Please try again.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en" data-mdb-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Submit Project - <?php echo SITE_NAME; ?></title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.4.2/mdb.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: #1976d2;
        }
        
        .page-header {
            background: linear-gradient(135deg, var(--primary-color) 0%, #1565c0 100%);
            color: white;
            padding: 60px 0;
        }
        
        .upload-area {
            border: 2px dashed #ccc;
            border-radius: 10px;
            padding: 40px;
            text-align: center;
            transition: all 0.3s;
            cursor: pointer;
        }
        
        .upload-area:hover {
            border-color: var(--primary-color);
            background: rgba(25, 118, 210, 0.05);
        }
        
        .file-list {
            max-height: 200px;
            overflow-y: auto;
        }
        
        .file-item {
            padding: 10px;
            border: 1px solid #eee;
            border-radius: 5px;
            margin-bottom: 10px;
        }
        
        [data-mdb-theme="dark"] .page-header {
            background: linear-gradient(135deg, #0d47a1 0%, #01579b 100%);
        }
        
        [data-mdb-theme="dark"] .upload-area {
            border-color: #444;
            background: #1e1e1e;
        }
        
        [data-mdb-theme="dark"] .file-item {
            border-color: #333;
            background: #1e1e1e;
        }
        
        @media (max-width: 768px) {
            .page-header {
                padding: 40px 0;
            }
            
            .upload-area {
                padding: 30px 15px;
            }
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light shadow-sm sticky-top">
        <div class="container">
            <a class="navbar-brand fw-bold" href="index.php">
                <i class="fas fa-film me-2"></i><?php echo SITE_NAME; ?>
            </a>
            
            <button class="navbar-toggler" type="button" data-mdb-toggle="collapse" data-mdb-target="#navbarNav">
                <i class="fas fa-bars"></i>
            </button>
            
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto align-items-center">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="my-projects.php">My Projects</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-mdb-toggle="dropdown">
                            <i class="fas fa-user-circle"></i> <?php echo htmlspecialchars($_SESSION['user_name']); ?>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="profile.php">Profile</a></li>
                            <li><a class="dropdown-item" href="logout.php">Logout</a></li>
                        </ul>
                    </li>
                    <li class="nav-item ms-2">
                        <button class="btn btn-sm btn-outline-secondary" id="theme-toggle">
                            <i class="fas fa-moon"></i>
                        </button>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Page Header -->
    <div class="page-header">
        <div class="container">
            <h1 class="fw-bold mb-2">Submit New Project</h1>
            <p class="mb-0">Fill in the details and upload your files to get started</p>
        </div>
    </div>

    <!-- Main Content -->
    <div class="container my-5">
        <div class="row justify-content-center">
            <div class="col-lg-10">
                <?php if (!empty($errors)): ?>
                    <div class="alert alert-danger">
                        <h6 class="alert-heading">Please fix the following errors:</h6>
                        <ul class="mb-0">
                            <?php foreach ($errors as $error): ?>
                                <li><?php echo $error; ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>
                
                <?php if ($success): ?>
                    <div class="alert alert-success">
                        <i class="fas fa-check-circle me-2"></i><?php echo $success; ?>
                    </div>
                <?php endif; ?>

                <div class="card">
                    <div class="card-body p-4">
                        <form method="POST" action="" enctype="multipart/form-data">
                            <h5 class="fw-bold mb-4">Project Details</h5>
                            
                            <div class="row">
                                <div class="col-md-8 mb-4">
                                    <div class="form-outline">
                                        <input type="text" name="title" class="form-control" required value="<?php echo isset($_POST['title']) ? htmlspecialchars($_POST['title']) : ''; ?>">
                                        <label class="form-label">Project Title *</label>
                                    </div>
                                </div>
                                
                                <div class="col-md-4 mb-4">
                                    <select name="service_id" class="form-select" required>
                                        <option value="">Select Service</option>
                                        <?php 
                                        $services_result->data_seek(0);
                                        while ($service = $services_result->fetch_assoc()): 
                                        ?>
                                            <option value="<?php echo $service['id']; ?>" <?php echo $service_id == $service['id'] ? 'selected' : ''; ?>>
                                                <?php echo htmlspecialchars($service['title']); ?>
                                            </option>
                                        <?php endwhile; ?>
                                    </select>
                                </div>
                            </div>
                            
                            <div class="form-outline mb-4">
                                <textarea name="description" class="form-control" rows="4" required><?php echo isset($_POST['description']) ? htmlspecialchars($_POST['description']) : ''; ?></textarea>
                                <label class="form-label">Project Description *</label>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6 mb-4">
                                    <div class="form-outline">
                                        <input type="text" name="project_type" class="form-control" value="<?php echo isset($_POST['project_type']) ? htmlspecialchars($_POST['project_type']) : ''; ?>">
                                        <label class="form-label">Project Type (e.g., Single, Album, Film)</label>
                                    </div>
                                </div>
                                
                                <div class="col-md-6 mb-4">
                                    <div class="form-outline">
                                        <input type="date" name="deadline" class="form-control" value="<?php echo isset($_POST['deadline']) ? htmlspecialchars($_POST['deadline']) : ''; ?>">
                                        <label class="form-label">Preferred Deadline</label>
                                    </div>
                                </div>
                            </div>
                            
                            <hr class="my-4">
                            
                            <h5 class="fw-bold mb-4">Project Metadata <small class="text-muted">(Optional)</small></h5>
                            
                            <div class="row">
                                <div class="col-md-6 mb-4">
                                    <div class="form-outline">
                                        <input type="text" name="isrc" class="form-control" value="<?php echo isset($_POST['isrc']) ? htmlspecialchars($_POST['isrc']) : ''; ?>">
                                        <label class="form-label">ISRC Code</label>
                                    </div>
                                </div>
                                
                                <div class="col-md-6 mb-4">
                                    <div class="form-outline">
                                        <input type="text" name="song_title" class="form-control" value="<?php echo isset($_POST['song_title']) ? htmlspecialchars($_POST['song_title']) : ''; ?>">
                                        <label class="form-label">Song/Track Title</label>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6 mb-4">
                                    <div class="form-outline">
                                        <input type="text" name="artist_name" class="form-control" value="<?php echo isset($_POST['artist_name']) ? htmlspecialchars($_POST['artist_name']) : ''; ?>">
                                        <label class="form-label">Artist Name</label>
                                    </div>
                                </div>
                                
                                <div class="col-md-6 mb-4">
                                    <div class="form-outline">
                                        <input type="text" name="album_name" class="form-control" value="<?php echo isset($_POST['album_name']) ? htmlspecialchars($_POST['album_name']) : ''; ?>">
                                        <label class="form-label">Album Name</label>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-4 mb-4">
                                    <div class="form-outline">
                                        <input type="date" name="release_date" class="form-control" value="<?php echo isset($_POST['release_date']) ? htmlspecialchars($_POST['release_date']) : ''; ?>">
                                        <label class="form-label">Release Date</label>
                                    </div>
                                </div>
                                
                                <div class="col-md-4 mb-4">
                                    <div class="form-outline">
                                        <input type="text" name="genre" class="form-control" value="<?php echo isset($_POST['genre']) ? htmlspecialchars($_POST['genre']) : ''; ?>">
                                        <label class="form-label">Genre</label>
                                    </div>
                                </div>
                                
                                <div class="col-md-4 mb-4">
                                    <div class="form-outline">
                                        <input type="text" name="label" class="form-control" value="<?php echo isset($_POST['label']) ? htmlspecialchars($_POST['label']) : ''; ?>">
                                        <label class="form-label">Label</label>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="form-outline mb-4">
                                <textarea name="additional_info" class="form-control" rows="3"><?php echo isset($_POST['additional_info']) ? htmlspecialchars($_POST['additional_info']) : ''; ?></textarea>
                                <label class="form-label">Additional Information</label>
                            </div>
                            
                            <hr class="my-4">
                            
                            <h5 class="fw-bold mb-4">Upload Files</h5>
                            
                            <div class="upload-area mb-3" onclick="document.getElementById('fileInput').click()">
                                <i class="fas fa-cloud-upload-alt fa-4x text-primary mb-3"></i>
                                <h5>Click to upload or drag and drop</h5>
                                <p class="text-muted mb-0">Supported: Audio, Video, Images, Documents (Max 100MB per file)</p>
                                <input type="file" id="fileInput" name="project_files[]" multiple style="display: none;" accept="audio/*,video/*,image/*,.pdf,.doc,.docx">
                            </div>
                            
                            <div class="file-list" id="fileList"></div>
                            
                            <div class="d-flex justify-content-between align-items-center mt-4">
                                <a href="dashboard.php" class="btn btn-outline-secondary">
                                    <i class="fas fa-arrow-left me-2"></i>Cancel
                                </a>
                                <button type="submit" class="btn btn-primary btn-lg">
                                    <i class="fas fa-paper-plane me-2"></i>Submit Project
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.4.2/mdb.min.js"></script>
    <script>
        // Theme toggle
        const themeToggle = document.getElementById('theme-toggle');
        const htmlElement = document.documentElement;
        const savedTheme = localStorage.getItem('theme') || 'light';
        htmlElement.setAttribute('data-mdb-theme', savedTheme);
        updateThemeIcon(savedTheme);
        
        themeToggle.addEventListener('click', () => {
            const currentTheme = htmlElement.getAttribute('data-mdb-theme');
            const newTheme = currentTheme === 'light' ? 'dark' : 'light';
            htmlElement.setAttribute('data-mdb-theme', newTheme);
            localStorage.setItem('theme', newTheme);
            updateThemeIcon(newTheme);
        });
        
        function updateThemeIcon(theme) {
            const icon = themeToggle.querySelector('i');
            icon.className = theme === 'light' ? 'fas fa-moon' : 'fas fa-sun';
        }
        
        // File upload handler
        const fileInput = document.getElementById('fileInput');
        const fileList = document.getElementById('fileList');
        
        fileInput.addEventListener('change', function() {
            fileList.innerHTML = '';
            
            if (this.files.length > 0) {
                Array.from(this.files).forEach((file, index) => {
                    const fileItem = document.createElement('div');
                    fileItem.className = 'file-item d-flex justify-content-between align-items-center';
                    fileItem.innerHTML = `
                        <div>
                            <i class="fas fa-file me-2"></i>
                            <strong>${file.name}</strong>
                            <small class="text-muted ms-2">(${formatFileSize(file.size)})</small>
                        </div>
                        <i class="fas fa-check-circle text-success"></i>
                    `;
                    fileList.appendChild(fileItem);
                });
            }
        });
        
        function formatFileSize(bytes) {
            if (bytes === 0) return '0 Bytes';
            const k = 1024;
            const sizes = ['Bytes', 'KB', 'MB', 'GB'];
            const i = Math.floor(Math.log(bytes) / Math.log(k));
            return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
        }
        
        // Drag and drop
        const uploadArea = document.querySelector('.upload-area');
        
        ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
            uploadArea.addEventListener(eventName, preventDefaults, false);
        });
        
        function preventDefaults(e) {
            e.preventDefault();
            e.stopPropagation();
        }
        
        ['dragenter', 'dragover'].forEach(eventName => {
            uploadArea.addEventListener(eventName, () => {
                uploadArea.style.borderColor = 'var(--primary-color)';
                uploadArea.style.background = 'rgba(25, 118, 210, 0.1)';
            }, false);
        });
        
        ['dragleave', 'drop'].forEach(eventName => {
            uploadArea.addEventListener(eventName, () => {
                uploadArea.style.borderColor = '#ccc';
                uploadArea.style.background = '';
            }, false);
        });
        
        uploadArea.addEventListener('drop', (e) => {
            const dt = e.dataTransfer;
            const files = dt.files;
            fileInput.files = files;
            fileInput.dispatchEvent(new Event('change'));
        }, false);
    </script>
</body>
</html>
