<?php
require_once 'config.php';

// Unset admin session variables
unset($_SESSION['admin_id']);
unset($_SESSION['admin_name']);
unset($_SESSION['admin_email']);
unset($_SESSION['admin_role']);

header('Location: login.php');
exit;
?>
