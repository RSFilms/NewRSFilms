<?php
require_once 'config.php';
requireAdmin();

// Get all projects
$projects = $conn->query("SELECT p.*, u.name as user_name, s.title as service_title 
                          FROM projects p 
                          LEFT JOIN users u ON p.user_id = u.id 
                          LEFT JOIN services s ON p.service_id = s.id 
                          ORDER BY p.created_at DESC");

// Update project status if requested
if (isset($_POST['update_status'])) {
    $project_id = (int)$_POST['project_id'];
    $status = sanitize($_POST['status']);
    $total_cost = (float)$_POST['total_cost'];
    
    $stmt = $conn->prepare("UPDATE projects SET status = ?, total_cost = ?, balance = total_cost - paid_amount WHERE id = ?");
    $stmt->bind_param("sdi", $status, $total_cost, $project_id);
    $stmt->execute();
    
    header('Location: projects.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en" data-mdb-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Projects - Admin</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.4.2/mdb.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        .sidebar { position: fixed; top: 0; left: 0; height: 100vh; width: 250px; background: #212529; color: white; overflow-y: auto; z-index: 1000; }
        .sidebar-header { padding: 20px; background: #1976d2; }
        .sidebar-menu { list-style: none; padding: 0; margin: 0; }
        .sidebar-menu li a { display: block; padding: 15px 20px; color: rgba(255,255,255,0.8); text-decoration: none; transition: all 0.3s; }
        .sidebar-menu li a:hover, .sidebar-menu li a.active { background: rgba(255,255,255,0.1); color: white; }
        .main-content { margin-left: 250px; min-height: 100vh; }
        .top-bar { background: white; padding: 15px 30px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .content-area { padding: 30px; }
        @media (max-width: 768px) { .sidebar { width: 60px; } .sidebar-header, .sidebar-menu li a span { display: none; } .main-content { margin-left: 60px; } }
    </style>
</head>
<body>
    <div class="sidebar">
        <div class="sidebar-header"><h5 class="mb-0 fw-bold"><i class="fas fa-film me-2"></i><span><?php echo SITE_NAME; ?></span></h5></div>
        <ul class="sidebar-menu">
            <li><a href="index.php"><i class="fas fa-home me-3"></i><span>Dashboard</span></a></li>
            <li><a href="projects.php" class="active"><i class="fas fa-folder me-3"></i><span>Projects</span></a></li>
            <li><a href="users.php"><i class="fas fa-users me-3"></i><span>Users</span></a></li>
            <li><a href="services.php"><i class="fas fa-briefcase me-3"></i><span>Services</span></a></li>
            <li><a href="finance.php"><i class="fas fa-dollar-sign me-3"></i><span>Finance</span></a></li>
            <li><a href="coupons.php"><i class="fas fa-tags me-3"></i><span>Coupons</span></a></li>
            <li><a href="support.php"><i class="fas fa-headset me-3"></i><span>Support</span></a></li>
            <li><a href="settings.php"><i class="fas fa-cog me-3"></i><span>Settings</span></a></li>
        </ul>
    </div>

    <div class="main-content">
        <div class="top-bar d-flex justify-content-between align-items-center">
            <h4 class="mb-0 fw-bold">Manage Projects</h4>
            <div class="dropdown">
                <button class="btn btn-primary dropdown-toggle" type="button" data-mdb-toggle="dropdown">
                    <i class="fas fa-user-circle me-2"></i><?php echo htmlspecialchars($_SESSION['admin_name']); ?>
                </button>
                <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                </ul>
            </div>
        </div>

        <div class="content-area">
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Title</th>
                                    <th>Client</th>
                                    <th>Service</th>
                                    <th>Status</th>
                                    <th>Cost</th>
                                    <th>Balance</th>
                                    <th>Created</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($project = $projects->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo $project['id']; ?></td>
                                    <td><?php echo htmlspecialchars($project['title']); ?></td>
                                    <td><?php echo htmlspecialchars($project['user_name']); ?></td>
                                    <td><?php echo htmlspecialchars($project['service_title'] ?? 'N/A'); ?></td>
                                    <td>
                                        <span class="badge bg-<?php echo ['pending'=>'warning','in_progress'=>'info','completed'=>'success'][$project['status']] ?? 'secondary'; ?>">
                                            <?php echo ucfirst($project['status']); ?>
                                        </span>
                                    </td>
                                    <td>₹<?php echo number_format($project['total_cost'], 0); ?></td>
                                    <td class="text-danger">₹<?php echo number_format($project['balance'], 0); ?></td>
                                    <td><?php echo date('M d, Y', strtotime($project['created_at'])); ?></td>
                                    <td>
                                        <button class="btn btn-sm btn-primary" data-mdb-toggle="modal" data-mdb-target="#editModal<?php echo $project['id']; ?>">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                    </td>
                                </tr>
                                
                                <!-- Edit Modal -->
                                <div class="modal fade" id="editModal<?php echo $project['id']; ?>" tabindex="-1">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title">Edit Project</h5>
                                                <button type="button" class="btn-close" data-mdb-dismiss="modal"></button>
                                            </div>
                                            <form method="POST">
                                                <div class="modal-body">
                                                    <input type="hidden" name="project_id" value="<?php echo $project['id']; ?>">
                                                    <div class="mb-3">
                                                        <label class="form-label">Status</label>
                                                        <select name="status" class="form-select" required>
                                                            <option value="pending" <?php echo $project['status']=='pending'?'selected':''; ?>>Pending</option>
                                                            <option value="in_progress" <?php echo $project['status']=='in_progress'?'selected':''; ?>>In Progress</option>
                                                            <option value="review" <?php echo $project['status']=='review'?'selected':''; ?>>Review</option>
                                                            <option value="completed" <?php echo $project['status']=='completed'?'selected':''; ?>>Completed</option>
                                                            <option value="cancelled" <?php echo $project['status']=='cancelled'?'selected':''; ?>>Cancelled</option>
                                                        </select>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label class="form-label">Total Cost (₹)</label>
                                                        <input type="number" name="total_cost" class="form-control" step="0.01" value="<?php echo $project['total_cost']; ?>" required>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-mdb-dismiss="modal">Cancel</button>
                                                    <button type="submit" name="update_status" class="btn btn-primary">Save Changes</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.4.2/mdb.min.js"></script>
</body>
</html>
