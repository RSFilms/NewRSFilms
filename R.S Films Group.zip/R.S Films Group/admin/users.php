<?php
require_once 'config.php';
requireAdmin();

// Get all users
$users = $conn->query("SELECT u.*, COUNT(p.id) as project_count, COALESCE(SUM(p.total_cost), 0) as total_spent 
                       FROM users u 
                       LEFT JOIN projects p ON u.id = p.user_id 
                       GROUP BY u.id 
                       ORDER BY u.created_at DESC");

// Block/Unblock user
if (isset($_POST['toggle_status'])) {
    $user_id = (int)$_POST['user_id'];
    $new_status = $_POST['new_status'] === 'active' ? 'blocked' : 'active';
    
    $stmt = $conn->prepare("UPDATE users SET status = ? WHERE id = ?");
    $stmt->bind_param("si", $new_status, $user_id);
    $stmt->execute();
    
    header('Location: users.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en" data-mdb-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users - Admin</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.4.2/mdb.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        .sidebar { position: fixed; top: 0; left: 0; height: 100vh; width: 250px; background: #212529; color: white; overflow-y: auto; z-index: 1000; }
        .sidebar-header { padding: 20px; background: #1976d2; }
        .sidebar-menu { list-style: none; padding: 0; margin: 0; }
        .sidebar-menu li a { display: block; padding: 15px 20px; color: rgba(255,255,255,0.8); text-decoration: none; transition: all 0.3s; }
        .sidebar-menu li a:hover, .sidebar-menu li a.active { background: rgba(255,255,255,0.1); color: white; }
        .main-content { margin-left: 250px; min-height: 100vh; }
        .top-bar { background: white; padding: 15px 30px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .content-area { padding: 30px; }
        @media (max-width: 768px) { .sidebar { width: 60px; } .sidebar-header, .sidebar-menu li a span { display: none; } .main-content { margin-left: 60px; } }
    </style>
</head>
<body>
    <div class="sidebar">
        <div class="sidebar-header"><h5 class="mb-0 fw-bold"><i class="fas fa-film me-2"></i><span><?php echo SITE_NAME; ?></span></h5></div>
        <ul class="sidebar-menu">
            <li><a href="index.php"><i class="fas fa-home me-3"></i><span>Dashboard</span></a></li>
            <li><a href="projects.php"><i class="fas fa-folder me-3"></i><span>Projects</span></a></li>
            <li><a href="users.php" class="active"><i class="fas fa-users me-3"></i><span>Users</span></a></li>
            <li><a href="services.php"><i class="fas fa-briefcase me-3"></i><span>Services</span></a></li>
            <li><a href="finance.php"><i class="fas fa-dollar-sign me-3"></i><span>Finance</span></a></li>
            <li><a href="coupons.php"><i class="fas fa-tags me-3"></i><span>Coupons</span></a></li>
            <li><a href="support.php"><i class="fas fa-headset me-3"></i><span>Support</span></a></li>
            <li><a href="settings.php"><i class="fas fa-cog me-3"></i><span>Settings</span></a></li>
        </ul>
    </div>

    <div class="main-content">
        <div class="top-bar d-flex justify-content-between align-items-center">
            <h4 class="mb-0 fw-bold">Manage Users</h4>
            <div class="dropdown">
                <button class="btn btn-primary dropdown-toggle" type="button" data-mdb-toggle="dropdown">
                    <i class="fas fa-user-circle me-2"></i><?php echo htmlspecialchars($_SESSION['admin_name']); ?>
                </button>
                <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                </ul>
            </div>
        </div>

        <div class="content-area">
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Phone</th>
                                    <th>Projects</th>
                                    <th>Total Spent</th>
                                    <th>Status</th>
                                    <th>Joined</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($user = $users->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo $user['id']; ?></td>
                                    <td><?php echo htmlspecialchars($user['name']); ?></td>
                                    <td><?php echo htmlspecialchars($user['email']); ?></td>
                                    <td><?php echo htmlspecialchars($user['phone'] ?? 'N/A'); ?></td>
                                    <td><?php echo $user['project_count']; ?></td>
                                    <td class="fw-bold">₹<?php echo number_format($user['total_spent'], 0); ?></td>
                                    <td>
                                        <span class="badge bg-<?php echo $user['status']==='active'?'success':'danger'; ?>">
                                            <?php echo ucfirst($user['status']); ?>
                                        </span>
                                    </td>
                                    <td><?php echo date('M d, Y', strtotime($user['created_at'])); ?></td>
                                    <td>
                                        <form method="POST" style="display:inline;">
                                            <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                            <input type="hidden" name="new_status" value="<?php echo $user['status']; ?>">
                                            <button type="submit" name="toggle_status" class="btn btn-sm btn-<?php echo $user['status']==='active'?'danger':'success'; ?>">
                                                <i class="fas fa-<?php echo $user['status']==='active'?'ban':'check'; ?>"></i>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.4.2/mdb.min.js"></script>
</body>
</html>
