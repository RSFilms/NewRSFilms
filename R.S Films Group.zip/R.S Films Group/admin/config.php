<?php
// Include main config
require_once dirname(__DIR__) . '/config.php';

// Admin-specific session check
function requireAdmin() {
    if (!isAdmin()) {
        header('Location: login.php');
        exit;
    }
}

// Get admin info
function getAdminInfo() {
    global $conn;
    if (isAdmin()) {
        $admin_id = $_SESSION['admin_id'];
        $stmt = $conn->prepare("SELECT * FROM admins WHERE id = ?");
        $stmt->bind_param("i", $admin_id);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    }
    return null;
}
?>
