<?php
require_once 'config.php';
requireAdmin();

$success = '';
$errors = [];

// Update settings
if (isset($_POST['update_settings'])) {
    $settings_data = [
        'site_name' => sanitize($_POST['site_name']),
        'site_email' => sanitize($_POST['site_email']),
        'site_phone' => sanitize($_POST['site_phone']),
        'payment_gateway' => sanitize($_POST['payment_gateway']),
        'razorpay_key_id' => sanitize($_POST['razorpay_key_id']),
        'razorpay_key_secret' => sanitize($_POST['razorpay_key_secret']),
        'stripe_public_key' => sanitize($_POST['stripe_public_key']),
        'stripe_secret_key' => sanitize($_POST['stripe_secret_key']),
        'paypal_client_id' => sanitize($_POST['paypal_client_id']),
        'paypal_client_secret' => sanitize($_POST['paypal_client_secret']),
        'tax_percentage' => sanitize($_POST['tax_percentage']),
        'currency_symbol' => sanitize($_POST['currency_symbol']),
        'enable_notifications' => isset($_POST['enable_notifications']) ? '1' : '0'
    ];
    
    $all_updated = true;
    foreach ($settings_data as $key => $value) {
        $stmt = $conn->prepare("INSERT INTO settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = ?");
        $stmt->bind_param("sss", $key, $value, $value);
        if (!$stmt->execute()) {
            $all_updated = false;
        }
    }
    
    if ($all_updated) {
        $success = 'Settings updated successfully!';
    } else {
        $errors[] = 'Some settings could not be updated';
    }
}

// Get current settings
$settings = [];
$result = $conn->query("SELECT setting_key, setting_value FROM settings");
while ($row = $result->fetch_assoc()) {
    $settings[$row['setting_key']] = $row['setting_value'];
}
?>
<!DOCTYPE html>
<html lang="en" data-mdb-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Settings - Admin</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.4.2/mdb.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        .sidebar { position: fixed; top: 0; left: 0; height: 100vh; width: 250px; background: #212529; color: white; overflow-y: auto; z-index: 1000; }
        .sidebar-header { padding: 20px; background: #1976d2; }
        .sidebar-menu { list-style: none; padding: 0; margin: 0; }
        .sidebar-menu li a { display: block; padding: 15px 20px; color: rgba(255,255,255,0.8); text-decoration: none; transition: all 0.3s; }
        .sidebar-menu li a:hover, .sidebar-menu li a.active { background: rgba(255,255,255,0.1); color: white; }
        .main-content { margin-left: 250px; min-height: 100vh; }
        .top-bar { background: white; padding: 15px 30px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .content-area { padding: 30px; }
        .settings-section { background: white; padding: 25px; border-radius: 10px; margin-bottom: 20px; }
        .settings-section h5 { border-bottom: 2px solid #1976d2; padding-bottom: 10px; margin-bottom: 20px; }
        @media (max-width: 768px) { .sidebar { width: 60px; } .sidebar-header, .sidebar-menu li a span { display: none; } .main-content { margin-left: 60px; } }
    </style>
</head>
<body>
    <div class="sidebar">
        <div class="sidebar-header"><h5 class="mb-0 fw-bold"><i class="fas fa-film me-2"></i><span><?php echo SITE_NAME; ?></span></h5></div>
        <ul class="sidebar-menu">
            <li><a href="index.php"><i class="fas fa-home me-3"></i><span>Dashboard</span></a></li>
            <li><a href="projects.php"><i class="fas fa-folder me-3"></i><span>Projects</span></a></li>
            <li><a href="users.php"><i class="fas fa-users me-3"></i><span>Users</span></a></li>
            <li><a href="services.php"><i class="fas fa-briefcase me-3"></i><span>Services</span></a></li>
            <li><a href="finance.php"><i class="fas fa-dollar-sign me-3"></i><span>Finance</span></a></li>
            <li><a href="coupons.php"><i class="fas fa-tags me-3"></i><span>Coupons</span></a></li>
            <li><a href="support.php"><i class="fas fa-headset me-3"></i><span>Support</span></a></li>
            <li><a href="settings.php" class="active"><i class="fas fa-cog me-3"></i><span>Settings</span></a></li>
        </ul>
    </div>

    <div class="main-content">
        <div class="top-bar d-flex justify-content-between align-items-center">
            <h4 class="mb-0 fw-bold">System Settings</h4>
            <div class="dropdown">
                <button class="btn btn-primary dropdown-toggle" type="button" data-mdb-toggle="dropdown">
                    <i class="fas fa-user-circle me-2"></i><?php echo htmlspecialchars($_SESSION['admin_name']); ?>
                </button>
                <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                </ul>
            </div>
        </div>

        <div class="content-area">
            <?php if ($success): ?>
                <div class="alert alert-success alert-dismissible fade show">
                    <i class="fas fa-check-circle me-2"></i><?php echo $success; ?>
                    <button type="button" class="btn-close" data-mdb-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            
            <?php if (!empty($errors)): ?>
                <div class="alert alert-danger alert-dismissible fade show">
                    <ul class="mb-0"><?php foreach ($errors as $error): ?><li><?php echo $error; ?></li><?php endforeach; ?></ul>
                    <button type="button" class="btn-close" data-mdb-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <form method="POST">
                <!-- General Settings -->
                <div class="settings-section">
                    <h5><i class="fas fa-globe me-2"></i>General Settings</h5>
                    <div class="row">
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Site Name</label>
                            <input type="text" name="site_name" class="form-control" value="<?php echo htmlspecialchars($settings['site_name'] ?? ''); ?>" required>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Contact Email</label>
                            <input type="email" name="site_email" class="form-control" value="<?php echo htmlspecialchars($settings['site_email'] ?? ''); ?>" required>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Contact Phone</label>
                            <input type="tel" name="site_phone" class="form-control" value="<?php echo htmlspecialchars($settings['site_phone'] ?? ''); ?>" required>
                        </div>
                    </div>
                </div>

                <!-- Payment Gateway Settings -->
                <div class="settings-section">
                    <h5><i class="fas fa-credit-card me-2"></i>Payment Gateway Settings</h5>
                    <div class="mb-4">
                        <label class="form-label">Active Payment Gateway</label>
                        <select name="payment_gateway" class="form-select">
                            <option value="razorpay" <?php echo ($settings['payment_gateway'] ?? '') === 'razorpay' ? 'selected' : ''; ?>>Razorpay</option>
                            <option value="stripe" <?php echo ($settings['payment_gateway'] ?? '') === 'stripe' ? 'selected' : ''; ?>>Stripe</option>
                            <option value="paypal" <?php echo ($settings['payment_gateway'] ?? '') === 'paypal' ? 'selected' : ''; ?>>PayPal</option>
                        </select>
                    </div>

                    <!-- Razorpay -->
                    <div class="mb-4">
                        <h6 class="fw-bold mb-3">Razorpay Configuration</h6>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Razorpay Key ID</label>
                                <input type="text" name="razorpay_key_id" class="form-control" value="<?php echo htmlspecialchars($settings['razorpay_key_id'] ?? ''); ?>" placeholder="rzp_test_...">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Razorpay Key Secret</label>
                                <input type="password" name="razorpay_key_secret" class="form-control" value="<?php echo htmlspecialchars($settings['razorpay_key_secret'] ?? ''); ?>" placeholder="Enter secret key">
                            </div>
                        </div>
                    </div>

                    <!-- Stripe -->
                    <div class="mb-4">
                        <h6 class="fw-bold mb-3">Stripe Configuration</h6>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Stripe Public Key</label>
                                <input type="text" name="stripe_public_key" class="form-control" value="<?php echo htmlspecialchars($settings['stripe_public_key'] ?? ''); ?>" placeholder="pk_test_...">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Stripe Secret Key</label>
                                <input type="password" name="stripe_secret_key" class="form-control" value="<?php echo htmlspecialchars($settings['stripe_secret_key'] ?? ''); ?>" placeholder="sk_test_...">
                            </div>
                        </div>
                    </div>

                    <!-- PayPal -->
                    <div class="mb-4">
                        <h6 class="fw-bold mb-3">PayPal Configuration</h6>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">PayPal Client ID</label>
                                <input type="text" name="paypal_client_id" class="form-control" value="<?php echo htmlspecialchars($settings['paypal_client_id'] ?? ''); ?>" placeholder="Enter client ID">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">PayPal Client Secret</label>
                                <input type="password" name="paypal_client_secret" class="form-control" value="<?php echo htmlspecialchars($settings['paypal_client_secret'] ?? ''); ?>" placeholder="Enter client secret">
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Tax & Currency Settings -->
                <div class="settings-section">
                    <h5><i class="fas fa-percentage me-2"></i>Tax & Currency Settings</h5>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Tax Percentage (%)</label>
                            <input type="number" name="tax_percentage" class="form-control" step="0.01" value="<?php echo htmlspecialchars($settings['tax_percentage'] ?? '18'); ?>">
                            <small class="text-muted">GST/VAT percentage to be applied</small>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Currency Symbol</label>
                            <input type="text" name="currency_symbol" class="form-control" value="<?php echo htmlspecialchars($settings['currency_symbol'] ?? '₹'); ?>">
                            <small class="text-muted">Symbol to display for prices</small>
                        </div>
                    </div>
                </div>

                <!-- Notification Settings -->
                <div class="settings-section">
                    <h5><i class="fas fa-bell me-2"></i>Notification Settings</h5>
                    <div class="form-check form-switch mb-3">
                        <input class="form-check-input" type="checkbox" name="enable_notifications" id="enableNotifications" <?php echo ($settings['enable_notifications'] ?? '1') === '1' ? 'checked' : ''; ?>>
                        <label class="form-check-label" for="enableNotifications">
                            Enable Email Notifications
                        </label>
                    </div>
                    <small class="text-muted">When enabled, users will receive email notifications for project updates, payments, etc.</small>
                </div>

                <!-- System Information -->
                <div class="settings-section">
                    <h5><i class="fas fa-info-circle me-2"></i>System Information</h5>
                    <div class="row">
                        <div class="col-md-4 mb-3">
                            <p class="text-muted mb-1">PHP Version</p>
                            <p class="fw-bold"><?php echo phpversion(); ?></p>
                        </div>
                        <div class="col-md-4 mb-3">
                            <p class="text-muted mb-1">MySQL Version</p>
                            <p class="fw-bold"><?php echo $conn->server_info; ?></p>
                        </div>
                        <div class="col-md-4 mb-3">
                            <p class="text-muted mb-1">Upload Max Size</p>
                            <p class="fw-bold"><?php echo ini_get('upload_max_filesize'); ?></p>
                        </div>
                    </div>
                </div>

                <!-- Save Button -->
                <div class="text-end">
                    <button type="submit" name="update_settings" class="btn btn-primary btn-lg">
                        <i class="fas fa-save me-2"></i>Save Settings
                    </button>
                </div>
            </form>

            <!-- Database Backup -->
            <div class="settings-section mt-4">
                <h5><i class="fas fa-database me-2"></i>Database Management</h5>
                <div class="alert alert-info">
                    <i class="fas fa-info-circle me-2"></i>
                    <strong>Database Backup:</strong> Use phpMyAdmin or command line tools to backup your database regularly.
                </div>
                <div class="d-flex gap-2">
                    <a href="http://localhost/phpmyadmin" target="_blank" class="btn btn-outline-primary">
                        <i class="fas fa-external-link-alt me-2"></i>Open phpMyAdmin
                    </a>
                    <button type="button" class="btn btn-outline-secondary" onclick="alert('Use phpMyAdmin Export feature to backup database')">
                        <i class="fas fa-download me-2"></i>Backup Instructions
                    </button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.4.2/mdb.min.js"></script>
</body>
</html>
