<?php
require_once 'config.php';
requireAdmin();

// Get statistics
$stats = [];

// Total users
$result = $conn->query("SELECT COUNT(*) as count FROM users WHERE status = 'active'");
$stats['users'] = $result->fetch_assoc()['count'];

// Total projects
$result = $conn->query("SELECT COUNT(*) as count FROM projects");
$stats['projects'] = $result->fetch_assoc()['count'];

// Pending projects
$result = $conn->query("SELECT COUNT(*) as count FROM projects WHERE status = 'pending'");
$stats['pending'] = $result->fetch_assoc()['count'];

// Total revenue
$result = $conn->query("SELECT COALESCE(SUM(paid_amount), 0) as total FROM projects");
$stats['revenue'] = $result->fetch_assoc()['total'];

// Outstanding balance
$result = $conn->query("SELECT COALESCE(SUM(balance), 0) as total FROM projects");
$stats['outstanding'] = $result->fetch_assoc()['total'];

// Recent projects
$recent_projects = $conn->query("SELECT p.*, u.name as user_name, s.title as service_title 
                                 FROM projects p 
                                 LEFT JOIN users u ON p.user_id = u.id 
                                 LEFT JOIN services s ON p.service_id = s.id 
                                 ORDER BY p.created_at DESC LIMIT 10");

// Recent users
$recent_users = $conn->query("SELECT * FROM users ORDER BY created_at DESC LIMIT 5");
?>
<!DOCTYPE html>
<html lang="en" data-mdb-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - <?php echo SITE_NAME; ?></title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.4.2/mdb.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root { --primary-color: #1976d2; }
        .sidebar { position: fixed; top: 0; left: 0; height: 100vh; width: 250px; background: #212529; color: white; overflow-y: auto; z-index: 1000; }
        .sidebar-header { padding: 20px; background: #1976d2; }
        .sidebar-menu { list-style: none; padding: 0; margin: 0; }
        .sidebar-menu li a { display: block; padding: 15px 20px; color: rgba(255,255,255,0.8); text-decoration: none; transition: all 0.3s; }
        .sidebar-menu li a:hover, .sidebar-menu li a.active { background: rgba(255,255,255,0.1); color: white; }
        .main-content { margin-left: 250px; min-height: 100vh; }
        .top-bar { background: white; padding: 15px 30px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .content-area { padding: 30px; }
        .stat-card { border-left: 4px solid var(--primary-color); }
        [data-mdb-theme="dark"] .sidebar { background: #1a1a1a; }
        [data-mdb-theme="dark"] .top-bar { background: #1e1e1e; }
        @media (max-width: 768px) {
            .sidebar { width: 60px; }
            .sidebar-header, .sidebar-menu li a span { display: none; }
            .main-content { margin-left: 60px; }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h5 class="mb-0 fw-bold"><i class="fas fa-film me-2"></i><span><?php echo SITE_NAME; ?></span></h5>
        </div>
        <ul class="sidebar-menu">
            <li><a href="index.php" class="active"><i class="fas fa-home me-3"></i><span>Dashboard</span></a></li>
            <li><a href="projects.php"><i class="fas fa-folder me-3"></i><span>Projects</span></a></li>
            <li><a href="users.php"><i class="fas fa-users me-3"></i><span>Users</span></a></li>
            <li><a href="services.php"><i class="fas fa-briefcase me-3"></i><span>Services</span></a></li>
            <li><a href="finance.php"><i class="fas fa-dollar-sign me-3"></i><span>Finance</span></a></li>
            <li><a href="coupons.php"><i class="fas fa-tags me-3"></i><span>Coupons</span></a></li>
            <li><a href="support.php"><i class="fas fa-headset me-3"></i><span>Support</span></a></li>
            <li><a href="settings.php"><i class="fas fa-cog me-3"></i><span>Settings</span></a></li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Top Bar -->
        <div class="top-bar d-flex justify-content-between align-items-center">
            <h4 class="mb-0 fw-bold">Dashboard</h4>
            <div class="d-flex align-items-center">
                <button class="btn btn-sm btn-outline-secondary me-3" id="theme-toggle"><i class="fas fa-moon"></i></button>
                <div class="dropdown">
                    <button class="btn btn-primary dropdown-toggle" type="button" data-mdb-toggle="dropdown">
                        <i class="fas fa-user-circle me-2"></i><?php echo htmlspecialchars($_SESSION['admin_name']); ?>
                    </button>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="profile.php"><i class="fas fa-user me-2"></i>Profile</a></li>
                        <li><a class="dropdown-item" href="../index.php" target="_blank"><i class="fas fa-globe me-2"></i>View Website</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                    </ul>
                </div>
            </div>
        </div>

        <!-- Content Area -->
        <div class="content-area">
            <!-- Statistics Cards -->
            <div class="row mb-4">
                <div class="col-md-3 mb-3">
                    <div class="card stat-card h-100">
                        <div class="card-body">
                            <div class="d-flex justify-content-between">
                                <div>
                                    <p class="text-muted mb-1">Total Users</p>
                                    <h3 class="fw-bold text-primary"><?php echo $stats['users']; ?></h3>
                                </div>
                                <i class="fas fa-users fa-3x text-primary opacity-50"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="card stat-card h-100" style="border-left-color: #ffc107;">
                        <div class="card-body">
                            <div class="d-flex justify-content-between">
                                <div>
                                    <p class="text-muted mb-1">Total Projects</p>
                                    <h3 class="fw-bold" style="color: #ffc107;"><?php echo $stats['projects']; ?></h3>
                                </div>
                                <i class="fas fa-folder fa-3x opacity-50" style="color: #ffc107;"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="card stat-card h-100" style="border-left-color: #28a745;">
                        <div class="card-body">
                            <div class="d-flex justify-content-between">
                                <div>
                                    <p class="text-muted mb-1">Total Revenue</p>
                                    <h3 class="fw-bold" style="color: #28a745;">₹<?php echo number_format($stats['revenue'], 0); ?></h3>
                                </div>
                                <i class="fas fa-rupee-sign fa-3x opacity-50" style="color: #28a745;"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="card stat-card h-100" style="border-left-color: #dc3545;">
                        <div class="card-body">
                            <div class="d-flex justify-content-between">
                                <div>
                                    <p class="text-muted mb-1">Pending Projects</p>
                                    <h3 class="fw-bold" style="color: #dc3545;"><?php echo $stats['pending']; ?></h3>
                                </div>
                                <i class="fas fa-clock fa-3x opacity-50" style="color: #dc3545;"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <!-- Recent Projects -->
                <div class="col-lg-8 mb-4">
                    <div class="card">
                        <div class="card-header bg-white d-flex justify-content-between align-items-center">
                            <h5 class="mb-0 fw-bold">Recent Projects</h5>
                            <a href="projects.php" class="btn btn-sm btn-link">View All</a>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>Project</th>
                                            <th>Client</th>
                                            <th>Service</th>
                                            <th>Status</th>
                                            <th>Amount</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php while ($project = $recent_projects->fetch_assoc()): ?>
                                        <tr>
                                            <td><a href="project-detail.php?id=<?php echo $project['id']; ?>"><?php echo htmlspecialchars($project['title']); ?></a></td>
                                            <td><?php echo htmlspecialchars($project['user_name']); ?></td>
                                            <td><?php echo htmlspecialchars($project['service_title'] ?? 'N/A'); ?></td>
                                            <td><span class="badge bg-warning"><?php echo ucfirst($project['status']); ?></span></td>
                                            <td>₹<?php echo number_format($project['total_cost'], 0); ?></td>
                                        </tr>
                                        <?php endwhile; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Recent Users -->
                <div class="col-lg-4 mb-4">
                    <div class="card">
                        <div class="card-header bg-white d-flex justify-content-between align-items-center">
                            <h5 class="mb-0 fw-bold">Recent Users</h5>
                            <a href="users.php" class="btn btn-sm btn-link">View All</a>
                        </div>
                        <div class="card-body">
                            <?php while ($user = $recent_users->fetch_assoc()): ?>
                            <div class="d-flex align-items-center mb-3 pb-3 border-bottom">
                                <div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 40px; height: 40px;">
                                    <i class="fas fa-user"></i>
                                </div>
                                <div>
                                    <h6 class="mb-0"><?php echo htmlspecialchars($user['name']); ?></h6>
                                    <small class="text-muted"><?php echo htmlspecialchars($user['email']); ?></small>
                                </div>
                            </div>
                            <?php endwhile; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.4.2/mdb.min.js"></script>
    <script>
        const themeToggle = document.getElementById('theme-toggle');
        const htmlElement = document.documentElement;
        const savedTheme = localStorage.getItem('theme') || 'light';
        htmlElement.setAttribute('data-mdb-theme', savedTheme);
        themeToggle.querySelector('i').className = savedTheme === 'light' ? 'fas fa-moon' : 'fas fa-sun';
        themeToggle.addEventListener('click', () => {
            const currentTheme = htmlElement.getAttribute('data-mdb-theme');
            const newTheme = currentTheme === 'light' ? 'dark' : 'light';
            htmlElement.setAttribute('data-mdb-theme', newTheme);
            localStorage.setItem('theme', newTheme);
            themeToggle.querySelector('i').className = newTheme === 'light' ? 'fas fa-moon' : 'fas fa-sun';
        });
    </script>
</body>
</html>
