<?php
require_once 'config.php';
requireAdmin();

$success = '';
$errors = [];

// Add new service
if (isset($_POST['add_service'])) {
    $title = sanitize($_POST['title']);
    $slug = strtolower(str_replace(' ', '-', $title));
    $description = sanitize($_POST['description']);
    $short_description = sanitize($_POST['short_description']);
    $category = sanitize($_POST['category']);
    $price_model = sanitize($_POST['price_model']);
    $base_price = (float)$_POST['base_price'];
    $features = sanitize($_POST['features']);
    $status = sanitize($_POST['status']);
    
    $stmt = $conn->prepare("INSERT INTO services (title, slug, description, short_description, category, price_model, base_price, features, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssssdss", $title, $slug, $description, $short_description, $category, $price_model, $base_price, $features, $status);
    
    if ($stmt->execute()) {
        $success = 'Service added successfully!';
    } else {
        $errors[] = 'Failed to add service: ' . $conn->error;
    }
}

// Update service
if (isset($_POST['update_service'])) {
    $id = (int)$_POST['service_id'];
    $title = sanitize($_POST['title']);
    $slug = strtolower(str_replace(' ', '-', $title));
    $description = sanitize($_POST['description']);
    $short_description = sanitize($_POST['short_description']);
    $category = sanitize($_POST['category']);
    $price_model = sanitize($_POST['price_model']);
    $base_price = (float)$_POST['base_price'];
    $features = sanitize($_POST['features']);
    $status = sanitize($_POST['status']);
    
    $stmt = $conn->prepare("UPDATE services SET title=?, slug=?, description=?, short_description=?, category=?, price_model=?, base_price=?, features=?, status=? WHERE id=?");
    $stmt->bind_param("ssssssdssi", $title, $slug, $description, $short_description, $category, $price_model, $base_price, $features, $status, $id);
    
    if ($stmt->execute()) {
        $success = 'Service updated successfully!';
    } else {
        $errors[] = 'Failed to update service: ' . $conn->error;
    }
}

// Delete service
if (isset($_POST['delete_service'])) {
    $id = (int)$_POST['service_id'];
    $stmt = $conn->prepare("DELETE FROM services WHERE id = ?");
    $stmt->bind_param("i", $id);
    
    if ($stmt->execute()) {
        $success = 'Service deleted successfully!';
    } else {
        $errors[] = 'Failed to delete service: ' . $conn->error;
    }
}

// Get all services
$services = $conn->query("SELECT * FROM services ORDER BY created_at DESC");
?>
<!DOCTYPE html>
<html lang="en" data-mdb-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Services - Admin</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.4.2/mdb.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        .sidebar { position: fixed; top: 0; left: 0; height: 100vh; width: 250px; background: #212529; color: white; overflow-y: auto; z-index: 1000; }
        .sidebar-header { padding: 20px; background: #1976d2; }
        .sidebar-menu { list-style: none; padding: 0; margin: 0; }
        .sidebar-menu li a { display: block; padding: 15px 20px; color: rgba(255,255,255,0.8); text-decoration: none; transition: all 0.3s; }
        .sidebar-menu li a:hover, .sidebar-menu li a.active { background: rgba(255,255,255,0.1); color: white; }
        .main-content { margin-left: 250px; min-height: 100vh; }
        .top-bar { background: white; padding: 15px 30px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .content-area { padding: 30px; }
        @media (max-width: 768px) { .sidebar { width: 60px; } .sidebar-header, .sidebar-menu li a span { display: none; } .main-content { margin-left: 60px; } }
    </style>
</head>
<body>
    <div class="sidebar">
        <div class="sidebar-header"><h5 class="mb-0 fw-bold"><i class="fas fa-film me-2"></i><span><?php echo SITE_NAME; ?></span></h5></div>
        <ul class="sidebar-menu">
            <li><a href="index.php"><i class="fas fa-home me-3"></i><span>Dashboard</span></a></li>
            <li><a href="projects.php"><i class="fas fa-folder me-3"></i><span>Projects</span></a></li>
            <li><a href="users.php"><i class="fas fa-users me-3"></i><span>Users</span></a></li>
            <li><a href="services.php" class="active"><i class="fas fa-briefcase me-3"></i><span>Services</span></a></li>
            <li><a href="finance.php"><i class="fas fa-dollar-sign me-3"></i><span>Finance</span></a></li>
            <li><a href="coupons.php"><i class="fas fa-tags me-3"></i><span>Coupons</span></a></li>
            <li><a href="support.php"><i class="fas fa-headset me-3"></i><span>Support</span></a></li>
            <li><a href="settings.php"><i class="fas fa-cog me-3"></i><span>Settings</span></a></li>
        </ul>
    </div>

    <div class="main-content">
        <div class="top-bar d-flex justify-content-between align-items-center">
            <h4 class="mb-0 fw-bold">Manage Services</h4>
            <div class="d-flex align-items-center">
                <button class="btn btn-primary me-3" data-mdb-toggle="modal" data-mdb-target="#addServiceModal">
                    <i class="fas fa-plus me-2"></i>Add Service
                </button>
                <div class="dropdown">
                    <button class="btn btn-primary dropdown-toggle" type="button" data-mdb-toggle="dropdown">
                        <i class="fas fa-user-circle me-2"></i><?php echo htmlspecialchars($_SESSION['admin_name']); ?>
                    </button>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                    </ul>
                </div>
            </div>
        </div>

        <div class="content-area">
            <?php if ($success): ?>
                <div class="alert alert-success alert-dismissible fade show">
                    <i class="fas fa-check-circle me-2"></i><?php echo $success; ?>
                    <button type="button" class="btn-close" data-mdb-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            
            <?php if (!empty($errors)): ?>
                <div class="alert alert-danger alert-dismissible fade show">
                    <ul class="mb-0"><?php foreach ($errors as $error): ?><li><?php echo $error; ?></li><?php endforeach; ?></ul>
                    <button type="button" class="btn-close" data-mdb-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Title</th>
                                    <th>Category</th>
                                    <th>Price Model</th>
                                    <th>Base Price</th>
                                    <th>Status</th>
                                    <th>Created</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($service = $services->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo $service['id']; ?></td>
                                    <td><strong><?php echo htmlspecialchars($service['title']); ?></strong></td>
                                    <td><span class="badge bg-primary"><?php echo htmlspecialchars($service['category']); ?></span></td>
                                    <td><?php echo ucfirst(str_replace('_', ' ', $service['price_model'])); ?></td>
                                    <td class="fw-bold">₹<?php echo number_format($service['base_price'], 0); ?></td>
                                    <td>
                                        <span class="badge bg-<?php echo $service['status']==='active'?'success':'secondary'; ?>">
                                            <?php echo ucfirst($service['status']); ?>
                                        </span>
                                    </td>
                                    <td><?php echo date('M d, Y', strtotime($service['created_at'])); ?></td>
                                    <td>
                                        <button class="btn btn-sm btn-info" data-mdb-toggle="modal" data-mdb-target="#editModal<?php echo $service['id']; ?>">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button class="btn btn-sm btn-danger" data-mdb-toggle="modal" data-mdb-target="#deleteModal<?php echo $service['id']; ?>">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </td>
                                </tr>
                                
                                <!-- Edit Modal -->
                                <div class="modal fade" id="editModal<?php echo $service['id']; ?>" tabindex="-1">
                                    <div class="modal-dialog modal-lg">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title">Edit Service</h5>
                                                <button type="button" class="btn-close" data-mdb-dismiss="modal"></button>
                                            </div>
                                            <form method="POST">
                                                <div class="modal-body">
                                                    <input type="hidden" name="service_id" value="<?php echo $service['id']; ?>">
                                                    <div class="row">
                                                        <div class="col-md-8 mb-3">
                                                            <label class="form-label">Title</label>
                                                            <input type="text" name="title" class="form-control" value="<?php echo htmlspecialchars($service['title']); ?>" required>
                                                        </div>
                                                        <div class="col-md-4 mb-3">
                                                            <label class="form-label">Category</label>
                                                            <input type="text" name="category" class="form-control" value="<?php echo htmlspecialchars($service['category']); ?>" required>
                                                        </div>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label class="form-label">Short Description</label>
                                                        <input type="text" name="short_description" class="form-control" value="<?php echo htmlspecialchars($service['short_description']); ?>" required>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label class="form-label">Full Description</label>
                                                        <textarea name="description" class="form-control" rows="4" required><?php echo htmlspecialchars($service['description']); ?></textarea>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-4 mb-3">
                                                            <label class="form-label">Price Model</label>
                                                            <select name="price_model" class="form-select" required>
                                                                <option value="fixed" <?php echo $service['price_model']=='fixed'?'selected':''; ?>>Fixed</option>
                                                                <option value="hourly" <?php echo $service['price_model']=='hourly'?'selected':''; ?>>Hourly</option>
                                                                <option value="project_based" <?php echo $service['price_model']=='project_based'?'selected':''; ?>>Project Based</option>
                                                                <option value="custom" <?php echo $service['price_model']=='custom'?'selected':''; ?>>Custom</option>
                                                            </select>
                                                        </div>
                                                        <div class="col-md-4 mb-3">
                                                            <label class="form-label">Base Price (₹)</label>
                                                            <input type="number" name="base_price" class="form-control" step="0.01" value="<?php echo $service['base_price']; ?>" required>
                                                        </div>
                                                        <div class="col-md-4 mb-3">
                                                            <label class="form-label">Status</label>
                                                            <select name="status" class="form-select" required>
                                                                <option value="active" <?php echo $service['status']=='active'?'selected':''; ?>>Active</option>
                                                                <option value="inactive" <?php echo $service['status']=='inactive'?'selected':''; ?>>Inactive</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label class="form-label">Features (one per line)</label>
                                                        <textarea name="features" class="form-control" rows="4"><?php echo htmlspecialchars($service['features']); ?></textarea>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-mdb-dismiss="modal">Cancel</button>
                                                    <button type="submit" name="update_service" class="btn btn-primary">Save Changes</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>

                                <!-- Delete Modal -->
                                <div class="modal fade" id="deleteModal<?php echo $service['id']; ?>" tabindex="-1">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title">Delete Service</h5>
                                                <button type="button" class="btn-close" data-mdb-dismiss="modal"></button>
                                            </div>
                                            <form method="POST">
                                                <div class="modal-body">
                                                    <input type="hidden" name="service_id" value="<?php echo $service['id']; ?>">
                                                    <p>Are you sure you want to delete <strong><?php echo htmlspecialchars($service['title']); ?></strong>?</p>
                                                    <p class="text-danger"><i class="fas fa-exclamation-triangle me-2"></i>This action cannot be undone!</p>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-mdb-dismiss="modal">Cancel</button>
                                                    <button type="submit" name="delete_service" class="btn btn-danger">Delete Service</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Add Service Modal -->
    <div class="modal fade" id="addServiceModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add New Service</h5>
                    <button type="button" class="btn-close" data-mdb-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-8 mb-3">
                                <label class="form-label">Title</label>
                                <input type="text" name="title" class="form-control" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Category</label>
                                <input type="text" name="category" class="form-control" placeholder="e.g., Audio, Video" required>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Short Description</label>
                            <input type="text" name="short_description" class="form-control" maxlength="500" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Full Description</label>
                            <textarea name="description" class="form-control" rows="4" required></textarea>
                        </div>
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Price Model</label>
                                <select name="price_model" class="form-select" required>
                                    <option value="fixed">Fixed</option>
                                    <option value="hourly">Hourly</option>
                                    <option value="project_based">Project Based</option>
                                    <option value="custom">Custom</option>
                                </select>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Base Price (₹)</label>
                                <input type="number" name="base_price" class="form-control" step="0.01" value="0" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Status</label>
                                <select name="status" class="form-select" required>
                                    <option value="active">Active</option>
                                    <option value="inactive">Inactive</option>
                                </select>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Features (one per line)</label>
                            <textarea name="features" class="form-control" rows="4" placeholder="Feature 1&#10;Feature 2&#10;Feature 3"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-mdb-dismiss="modal">Cancel</button>
                        <button type="submit" name="add_service" class="btn btn-primary">Add Service</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.4.2/mdb.min.js"></script>
</body>
</html>
