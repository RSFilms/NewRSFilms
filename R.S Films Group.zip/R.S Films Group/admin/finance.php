<?php
require_once 'config.php';
requireAdmin();

// Get financial statistics
$stats = [];
$result = $conn->query("SELECT COALESCE(SUM(total_cost), 0) as total FROM projects");
$stats['total_billed'] = $result->fetch_assoc()['total'];

$result = $conn->query("SELECT COALESCE(SUM(paid_amount), 0) as total FROM projects");
$stats['total_paid'] = $result->fetch_assoc()['total'];

$result = $conn->query("SELECT COALESCE(SUM(balance), 0) as total FROM projects");
$stats['outstanding'] = $result->fetch_assoc()['total'];

// Get all transactions
$transactions = $conn->query("SELECT fl.*, p.title as project_title, u.name as user_name 
                              FROM finance_ledger fl
                              LEFT JOIN projects p ON fl.project_id = p.id
                              LEFT JOIN users u ON fl.user_id = u.id
                              ORDER BY fl.transaction_date DESC");
?>
<!DOCTYPE html>
<html lang="en" data-mdb-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Finance Management - Admin</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.4.2/mdb.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        .sidebar { position: fixed; top: 0; left: 0; height: 100vh; width: 250px; background: #212529; color: white; overflow-y: auto; z-index: 1000; }
        .sidebar-header { padding: 20px; background: #1976d2; }
        .sidebar-menu { list-style: none; padding: 0; margin: 0; }
        .sidebar-menu li a { display: block; padding: 15px 20px; color: rgba(255,255,255,0.8); text-decoration: none; transition: all 0.3s; }
        .sidebar-menu li a:hover, .sidebar-menu li a.active { background: rgba(255,255,255,0.1); color: white; }
        .main-content { margin-left: 250px; min-height: 100vh; }
        .top-bar { background: white; padding: 15px 30px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .content-area { padding: 30px; }
        .stat-card { border-left: 4px solid #1976d2; }
        @media (max-width: 768px) { .sidebar { width: 60px; } .sidebar-header, .sidebar-menu li a span { display: none; } .main-content { margin-left: 60px; } }
    </style>
</head>
<body>
    <div class="sidebar">
        <div class="sidebar-header"><h5 class="mb-0 fw-bold"><i class="fas fa-film me-2"></i><span><?php echo SITE_NAME; ?></span></h5></div>
        <ul class="sidebar-menu">
            <li><a href="index.php"><i class="fas fa-home me-3"></i><span>Dashboard</span></a></li>
            <li><a href="projects.php"><i class="fas fa-folder me-3"></i><span>Projects</span></a></li>
            <li><a href="users.php"><i class="fas fa-users me-3"></i><span>Users</span></a></li>
            <li><a href="services.php"><i class="fas fa-briefcase me-3"></i><span>Services</span></a></li>
            <li><a href="finance.php" class="active"><i class="fas fa-dollar-sign me-3"></i><span>Finance</span></a></li>
            <li><a href="coupons.php"><i class="fas fa-tags me-3"></i><span>Coupons</span></a></li>
            <li><a href="support.php"><i class="fas fa-headset me-3"></i><span>Support</span></a></li>
            <li><a href="settings.php"><i class="fas fa-cog me-3"></i><span>Settings</span></a></li>
        </ul>
    </div>

    <div class="main-content">
        <div class="top-bar d-flex justify-content-between align-items-center">
            <h4 class="mb-0 fw-bold">Finance Management</h4>
            <div class="dropdown">
                <button class="btn btn-primary dropdown-toggle" type="button" data-mdb-toggle="dropdown">
                    <i class="fas fa-user-circle me-2"></i><?php echo htmlspecialchars($_SESSION['admin_name']); ?>
                </button>
                <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                </ul>
            </div>
        </div>

        <div class="content-area">
            <!-- Statistics -->
            <div class="row mb-4">
                <div class="col-md-4 mb-3">
                    <div class="card stat-card h-100">
                        <div class="card-body">
                            <p class="text-muted mb-2">Total Billed</p>
                            <h3 class="fw-bold text-primary mb-0">₹<?php echo number_format($stats['total_billed'], 2); ?></h3>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <div class="card stat-card h-100" style="border-left-color: #28a745;">
                        <div class="card-body">
                            <p class="text-muted mb-2">Total Paid</p>
                            <h3 class="fw-bold mb-0" style="color: #28a745;">₹<?php echo number_format($stats['total_paid'], 2); ?></h3>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <div class="card stat-card h-100" style="border-left-color: #dc3545;">
                        <div class="card-body">
                            <p class="text-muted mb-2">Outstanding</p>
                            <h3 class="fw-bold mb-0" style="color: #dc3545;">₹<?php echo number_format($stats['outstanding'], 2); ?></h3>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Transactions -->
            <div class="card">
                <div class="card-header bg-white">
                    <h5 class="mb-0 fw-bold">All Transactions</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Date</th>
                                    <th>Client</th>
                                    <th>Project</th>
                                    <th>Type</th>
                                    <th>Amount</th>
                                    <th>Status</th>
                                    <th>Method</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($transaction = $transactions->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo $transaction['id']; ?></td>
                                    <td><?php echo date('M d, Y', strtotime($transaction['transaction_date'])); ?></td>
                                    <td><?php echo htmlspecialchars($transaction['user_name'] ?? 'N/A'); ?></td>
                                    <td><?php echo htmlspecialchars($transaction['project_title'] ?? 'N/A'); ?></td>
                                    <td><span class="badge bg-info"><?php echo ucfirst($transaction['transaction_type']); ?></span></td>
                                    <td class="fw-bold <?php echo in_array($transaction['transaction_type'], ['credit','payment'])?'text-success':'text-danger'; ?>">
                                        ₹<?php echo number_format($transaction['amount'], 2); ?>
                                    </td>
                                    <td>
                                        <span class="badge bg-<?php echo $transaction['status']=='completed'?'success':'warning'; ?>">
                                            <?php echo ucfirst($transaction['status']); ?>
                                        </span>
                                    </td>
                                    <td><?php echo htmlspecialchars($transaction['payment_method'] ?? 'N/A'); ?></td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.4.2/mdb.min.js"></script>
</body>
</html>
