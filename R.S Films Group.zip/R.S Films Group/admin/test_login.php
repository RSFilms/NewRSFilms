<?php
// Admin Login Diagnostic Tool
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h2>🔍 Admin Login Diagnostic Tool</h2>";
echo "<hr>";

// Test 1: Check if config file exists
echo "<h3>Test 1: Configuration File</h3>";
if (file_exists('../config.php')) {
    echo "✅ config.php exists<br>";
    require_once '../config.php';
} else {
    echo "❌ config.php NOT found!<br>";
    exit;
}

// Test 2: Check database connection
echo "<h3>Test 2: Database Connection</h3>";
if ($conn && !$conn->connect_error) {
    echo "✅ Database connected successfully<br>";
    echo "Database name: " . DB_NAME . "<br>";
} else {
    echo "❌ Database connection failed: " . $conn->connect_error . "<br>";
    exit;
}

// Test 3: Check if admins table exists
echo "<h3>Test 3: Admins Table</h3>";
$result = $conn->query("SHOW TABLES LIKE 'admins'");
if ($result && $result->num_rows > 0) {
    echo "✅ Admins table exists<br>";
} else {
    echo "❌ Admins table NOT found!<br>";
    echo "<p style='color: red;'>Please import database.sql first!</p>";
    exit;
}

// Test 4: Check admin accounts
echo "<h3>Test 4: Admin Accounts</h3>";
$result = $conn->query("SELECT id, name, email, role, status FROM admins");
if ($result && $result->num_rows > 0) {
    echo "✅ Found " . $result->num_rows . " admin account(s)<br>";
    echo "<table border='1' cellpadding='5' style='margin-top: 10px;'>";
    echo "<tr><th>ID</th><th>Name</th><th>Email</th><th>Role</th><th>Status</th></tr>";
    while ($admin = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $admin['id'] . "</td>";
        echo "<td>" . $admin['name'] . "</td>";
        echo "<td>" . $admin['email'] . "</td>";
        echo "<td>" . $admin['role'] . "</td>";
        echo "<td>" . $admin['status'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "❌ No admin accounts found!<br>";
    echo "<p style='color: orange;'>You need to create an admin account.</p>";
}

// Test 5: Create/Reset Admin Account
echo "<h3>Test 5: Fix Admin Account</h3>";
echo "<form method='POST'>";
echo "<button type='submit' name='create_admin' style='padding: 10px 20px; background: #1976d2; color: white; border: none; border-radius: 5px; cursor: pointer;'>🔧 Create/Reset Admin Account</button>";
echo "</form>";

if (isset($_POST['create_admin'])) {
    echo "<div style='background: #f0f0f0; padding: 15px; margin-top: 10px; border-radius: 5px;'>";
    
    // Delete existing admin
    $conn->query("DELETE FROM admins WHERE email = 'admin@rsfilmsgroup.com'");
    
    // Create new admin with proper password hash
    $name = 'Super Admin';
    $email = 'admin@rsfilmsgroup.com';
    $password = 'admin123';
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    $role = 'super_admin';
    $status = 'active';
    
    $stmt = $conn->prepare("INSERT INTO admins (name, email, password, role, status) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $name, $email, $hashed_password, $role, $status);
    
    if ($stmt->execute()) {
        echo "<p style='color: green; font-weight: bold;'>✅ SUCCESS! Admin account created!</p>";
        echo "<p><strong>Email:</strong> admin@rsfilmsgroup.com</p>";
        echo "<p><strong>Password:</strong> admin123</p>";
        echo "<p style='color: red;'>⚠️ Change password after login!</p>";
        echo "<p><a href='login.php' style='display: inline-block; margin-top: 10px; padding: 10px 20px; background: #28a745; color: white; text-decoration: none; border-radius: 5px;'>Go to Login Page →</a></p>";
    } else {
        echo "<p style='color: red;'>❌ Failed: " . $conn->error . "</p>";
    }
    echo "</div>";
}

// Test 6: Test password verification
echo "<h3>Test 6: Test Login</h3>";
echo "<form method='POST'>";
echo "<input type='email' name='test_email' placeholder='Email' required style='padding: 8px; margin: 5px;'><br>";
echo "<input type='password' name='test_password' placeholder='Password' required style='padding: 8px; margin: 5px;'><br>";
echo "<button type='submit' name='test_login' style='padding: 10px 20px; background: #28a745; color: white; border: none; border-radius: 5px; cursor: pointer; margin: 5px;'>Test Login</button>";
echo "</form>";

if (isset($_POST['test_login'])) {
    $test_email = $_POST['test_email'];
    $test_password = $_POST['test_password'];
    
    echo "<div style='background: #f0f0f0; padding: 15px; margin-top: 10px; border-radius: 5px;'>";
    
    $stmt = $conn->prepare("SELECT id, name, password, status FROM admins WHERE email = ?");
    $stmt->bind_param("s", $test_email);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        echo "<p style='color: red;'>❌ No admin found with email: " . htmlspecialchars($test_email) . "</p>";
    } else {
        $admin = $result->fetch_assoc();
        echo "<p>✅ Admin found: " . htmlspecialchars($admin['name']) . "</p>";
        echo "<p>Status: " . $admin['status'] . "</p>";
        
        if ($admin['status'] !== 'active') {
            echo "<p style='color: red;'>❌ Account is inactive!</p>";
        } else {
            if (password_verify($test_password, $admin['password'])) {
                echo "<p style='color: green; font-weight: bold;'>✅ PASSWORD CORRECT! Login should work!</p>";
                echo "<p><a href='login.php' style='display: inline-block; margin-top: 10px; padding: 10px 20px; background: #1976d2; color: white; text-decoration: none; border-radius: 5px;'>Go to Login Page →</a></p>";
            } else {
                echo "<p style='color: red;'>❌ Password incorrect!</p>";
                echo "<p>Try password: <strong>admin123</strong></p>";
            }
        }
    }
    echo "</div>";
}

echo "<hr>";
echo "<p style='color: #666;'><small>After fixing the issue, you can delete this file (test_login.php) for security.</small></p>";
?>
