<?php
require_once 'config.php';

if (isAdmin()) {
    header('Location: index.php');
    exit;
}

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = sanitize($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    
    if (empty($email) || empty($password)) {
        $errors[] = 'Email and password are required';
    } else {
        $stmt = $conn->prepare("SELECT id, name, email, password, role, status FROM admins WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 1) {
            $admin = $result->fetch_assoc();
            
            if ($admin['status'] === 'inactive') {
                $errors[] = 'Your account has been deactivated.';
            } elseif (password_verify($password, $admin['password'])) {
                $_SESSION['admin_id'] = $admin['id'];
                $_SESSION['admin_name'] = $admin['name'];
                $_SESSION['admin_email'] = $admin['email'];
                $_SESSION['admin_role'] = $admin['role'];
                
                header('Location: index.php');
                exit;
            } else {
                $errors[] = 'Invalid email or password';
            }
        } else {
            $errors[] = 'Invalid email or password';
        }
        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en" data-mdb-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - <?php echo SITE_NAME; ?></title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.4.2/mdb.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body { background: linear-gradient(135deg, #1976d2 0%, #1565c0 100%); min-height: 100vh; display: flex; align-items: center; justify-content: center; }
        .auth-card { max-width: 450px; width: 100%; margin: 20px; }
    </style>
</head>
<body>
    <div class="auth-card">
        <div class="card shadow-lg">
            <div class="card-body p-5">
                <div class="text-center mb-4">
                    <i class="fas fa-user-shield fa-3x text-primary mb-3"></i>
                    <h2 class="fw-bold">Admin Login</h2>
                    <p class="text-muted"><?php echo SITE_NAME; ?></p>
                </div>
                
                <?php if (!empty($errors)): ?>
                    <div class="alert alert-danger">
                        <ul class="mb-0"><?php foreach ($errors as $error): ?><li><?php echo $error; ?></li><?php endforeach; ?></ul>
                    </div>
                <?php endif; ?>
                
                <form method="POST" action="">
                    <div class="form-outline mb-4">
                        <input type="email" name="email" class="form-control" required>
                        <label class="form-label">Email Address</label>
                    </div>
                    <div class="form-outline mb-4">
                        <input type="password" name="password" class="form-control" required>
                        <label class="form-label">Password</label>
                    </div>
                    <button type="submit" class="btn btn-primary w-100 mb-3">
                        <i class="fas fa-sign-in-alt me-2"></i>Login to Admin Panel
                    </button>
                    <div class="text-center">
                        <a href="../index.php" class="text-muted"><i class="fas fa-arrow-left me-2"></i>Back to Website</a>
                    </div>
                </form>
                
                <div class="alert alert-info mt-4 mb-0">
                    <small><strong>Default Admin:</strong><br>Email: admin@rsfilmsgroup.com<br>Password: admin123</small>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.4.2/mdb.min.js"></script>
</body>
</html>
