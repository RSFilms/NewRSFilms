<?php
require_once 'config.php';

if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Get financial summary
$finance_query = "SELECT 
                  COALESCE(SUM(total_cost), 0) as total_billed,
                  COALESCE(SUM(paid_amount), 0) as total_paid,
                  COALESCE(SUM(balance), 0) as outstanding
                  FROM projects WHERE user_id = ?";
$stmt = $conn->prepare($finance_query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$finance_summary = $stmt->get_result()->fetch_assoc();

// Get all transactions
$transactions_query = "SELECT fl.*, p.title as project_title 
                       FROM finance_ledger fl
                       LEFT JOIN projects p ON fl.project_id = p.id
                       WHERE fl.user_id = ?
                       ORDER BY fl.transaction_date DESC";
$stmt = $conn->prepare($transactions_query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$transactions = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en" data-mdb-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Finance Ledger - <?php echo SITE_NAME; ?></title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.4.2/mdb.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root { --primary-color: #1976d2; }
        .page-header { background: linear-gradient(135deg, var(--primary-color) 0%, #1565c0 100%); color: white; padding: 60px 0; }
        .stat-card { border-left: 4px solid var(--primary-color); }
        .transaction-item { padding: 15px; border-bottom: 1px solid #eee; }
        .transaction-item:last-child { border-bottom: none; }
        [data-mdb-theme="dark"] .page-header { background: linear-gradient(135deg, #0d47a1 0%, #01579b 100%); }
        [data-mdb-theme="dark"] .transaction-item { border-bottom-color: #333; }
        @media (max-width: 768px) { .page-header { padding: 40px 0; } }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light shadow-sm sticky-top">
        <div class="container">
            <a class="navbar-brand fw-bold" href="index.php"><i class="fas fa-film me-2"></i><?php echo SITE_NAME; ?></a>
            <button class="navbar-toggler" type="button" data-mdb-toggle="collapse" data-mdb-target="#navbarNav"><i class="fas fa-bars"></i></button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto align-items-center">
                    <li class="nav-item"><a class="nav-link" href="dashboard.php">Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link" href="my-projects.php">My Projects</a></li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-mdb-toggle="dropdown">
                            <i class="fas fa-user-circle"></i> <?php echo htmlspecialchars($_SESSION['user_name']); ?>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="profile.php">Profile</a></li>
                            <li><a class="dropdown-item" href="logout.php">Logout</a></li>
                        </ul>
                    </li>
                    <li class="nav-item ms-2">
                        <button class="btn btn-sm btn-outline-secondary" id="theme-toggle"><i class="fas fa-moon"></i></button>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="page-header">
        <div class="container">
            <h1 class="fw-bold mb-2">Finance Ledger</h1>
            <p class="mb-0">Track all your project costs and payments</p>
        </div>
    </div>

    <div class="container my-5">
        <div class="row mb-4">
            <div class="col-md-4 mb-3">
                <div class="card stat-card h-100">
                    <div class="card-body">
                        <p class="text-muted mb-2">Total Billed</p>
                        <h3 class="fw-bold text-primary mb-0">₹<?php echo number_format($finance_summary['total_billed'], 2); ?></h3>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-3">
                <div class="card stat-card h-100" style="border-left-color: #28a745;">
                    <div class="card-body">
                        <p class="text-muted mb-2">Total Paid</p>
                        <h3 class="fw-bold mb-0" style="color: #28a745;">₹<?php echo number_format($finance_summary['total_paid'], 2); ?></h3>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-3">
                <div class="card stat-card h-100" style="border-left-color: #dc3545;">
                    <div class="card-body">
                        <p class="text-muted mb-2">Outstanding</p>
                        <h3 class="fw-bold mb-0" style="color: #dc3545;">₹<?php echo number_format($finance_summary['outstanding'], 2); ?></h3>
                    </div>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-header bg-white">
                <h5 class="mb-0 fw-bold">Transaction History</h5>
            </div>
            <div class="card-body p-0">
                <?php if ($transactions->num_rows > 0): ?>
                    <?php while ($transaction = $transactions->fetch_assoc()): ?>
                    <div class="transaction-item">
                        <div class="row align-items-center">
                            <div class="col-md-6">
                                <h6 class="mb-1 fw-bold"><?php echo htmlspecialchars($transaction['description']); ?></h6>
                                <small class="text-muted">
                                    <i class="fas fa-folder me-1"></i><?php echo htmlspecialchars($transaction['project_title'] ?? 'N/A'); ?>
                                    <span class="mx-2">|</span>
                                    <i class="fas fa-calendar me-1"></i><?php echo date('M d, Y', strtotime($transaction['transaction_date'])); ?>
                                </small>
                            </div>
                            <div class="col-md-3 text-md-center mt-2 mt-md-0">
                                <span class="badge bg-<?php echo $transaction['status'] === 'completed' ? 'success' : ($transaction['status'] === 'pending' ? 'warning' : 'danger'); ?>">
                                    <?php echo ucfirst($transaction['status']); ?>
                                </span>
                                <?php if ($transaction['payment_method']): ?>
                                    <small class="text-muted d-block mt-1"><?php echo htmlspecialchars($transaction['payment_method']); ?></small>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-3 text-md-end mt-2 mt-md-0">
                                <h5 class="mb-0 fw-bold <?php echo in_array($transaction['transaction_type'], ['credit', 'payment']) ? 'text-success' : 'text-danger'; ?>">
                                    <?php echo in_array($transaction['transaction_type'], ['credit', 'payment']) ? '+' : '-'; ?>
                                    ₹<?php echo number_format($transaction['amount'], 2); ?>
                                </h5>
                                <small class="text-muted"><?php echo ucfirst($transaction['transaction_type']); ?></small>
                            </div>
                        </div>
                    </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <div class="text-center py-5">
                        <i class="fas fa-receipt fa-4x text-muted mb-3"></i>
                        <h4>No transactions yet</h4>
                        <p class="text-muted">Your transaction history will appear here</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.4.2/mdb.min.js"></script>
    <script>
        const themeToggle = document.getElementById('theme-toggle');
        const htmlElement = document.documentElement;
        const savedTheme = localStorage.getItem('theme') || 'light';
        htmlElement.setAttribute('data-mdb-theme', savedTheme);
        themeToggle.querySelector('i').className = savedTheme === 'light' ? 'fas fa-moon' : 'fas fa-sun';
        themeToggle.addEventListener('click', () => {
            const currentTheme = htmlElement.getAttribute('data-mdb-theme');
            const newTheme = currentTheme === 'light' ? 'dark' : 'light';
            htmlElement.setAttribute('data-mdb-theme', newTheme);
            localStorage.setItem('theme', newTheme);
            themeToggle.querySelector('i').className = newTheme === 'light' ? 'fas fa-moon' : 'fas fa-sun';
        });
    </script>
</body>
</html>
