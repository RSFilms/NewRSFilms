<?php
require_once 'config.php';
?>
<!DOCTYPE html>
<html lang="en" data-mdb-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo SITE_NAME; ?> - Professional Audio & Video Production Services</title>
    
    <!-- MDBootstrap CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.4.2/mdb.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    
    <style>
        :root {
            --primary-color: #1976d2;
            --secondary-color: #dc004e;
            --dark-bg: #121212;
            --dark-surface: #1e1e1e;
        }
        
        .hero-section {
            background: linear-gradient(135deg, var(--primary-color) 0%, #1565c0 100%);
            color: white;
            padding: 100px 0;
            min-height: 600px;
            display: flex;
            align-items: center;
        }
        
        .hero-content h1 {
            font-size: 3.5rem;
            font-weight: 700;
            margin-bottom: 20px;
        }
        
        .hero-content p {
            font-size: 1.3rem;
            margin-bottom: 30px;
            opacity: 0.9;
        }
        
        .service-card {
            transition: transform 0.3s, box-shadow 0.3s;
            height: 100%;
            cursor: pointer;
        }
        
        .service-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }
        
        .testimonial-card {
            background: white;
            border-radius: 15px;
            padding: 30px;
            margin: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .footer {
            background: #212121;
            color: white;
            padding: 50px 0 20px;
        }
        
        .stats-section {
            padding: 60px 0;
            background: #f8f9fa;
        }
        
        .stat-item {
            text-align: center;
            padding: 20px;
        }
        
        .stat-number {
            font-size: 3rem;
            font-weight: 700;
            color: var(--primary-color);
        }
        
        /* Mobile Bottom Navigation */
        .mobile-bottom-nav {
            display: none;
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: white;
            box-shadow: 0 -2px 10px rgba(0,0,0,0.1);
            z-index: 1000;
            padding: 10px 0;
        }
        
        .mobile-nav-item {
            text-align: center;
            color: #666;
            text-decoration: none;
            font-size: 0.75rem;
        }
        
        .mobile-nav-item i {
            font-size: 1.5rem;
            display: block;
            margin-bottom: 5px;
        }
        
        .mobile-nav-item.active {
            color: var(--primary-color);
        }
        
        /* Dark theme */
        [data-mdb-theme="dark"] {
            background-color: var(--dark-bg);
            color: #fff;
        }
        
        [data-mdb-theme="dark"] .hero-section {
            background: linear-gradient(135deg, #0d47a1 0%, #01579b 100%);
        }
        
        [data-mdb-theme="dark"] .service-card {
            background-color: var(--dark-surface);
        }
        
        [data-mdb-theme="dark"] .stats-section {
            background: var(--dark-surface);
        }
        
        [data-mdb-theme="dark"] .mobile-bottom-nav {
            background: var(--dark-surface);
            border-top: 1px solid #333;
        }
        
        @media (max-width: 768px) {
            .mobile-bottom-nav {
                display: flex;
            }
            
            body {
                padding-bottom: 70px;
            }
            
            .hero-content h1 {
                font-size: 2rem;
            }
            
            .hero-content p {
                font-size: 1rem;
            }
            
            .hero-section {
                padding: 60px 0;
                min-height: 400px;
            }
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light shadow-sm sticky-top">
        <div class="container">
            <a class="navbar-brand fw-bold" href="index.php">
                <i class="fas fa-film me-2"></i><?php echo SITE_NAME; ?>
            </a>
            
            <button class="navbar-toggler" type="button" data-mdb-toggle="collapse" data-mdb-target="#navbarNav">
                <i class="fas fa-bars"></i>
            </button>
            
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto align-items-center">
                    <li class="nav-item">
                        <a class="nav-link active" href="index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="services.php">Services</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="portfolio.php">Portfolio</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="contact.php">Contact</a>
                    </li>
                    <?php if (isLoggedIn()): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="dashboard.php">Dashboard</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="logout.php">Logout</a>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="btn btn-primary btn-sm ms-2" href="login.php">Login</a>
                        </li>
                        <li class="nav-item">
                            <a class="btn btn-outline-primary btn-sm ms-2" href="signup.php">Sign Up</a>
                        </li>
                    <?php endif; ?>
                    <li class="nav-item ms-2">
                        <button class="btn btn-sm btn-outline-secondary" id="theme-toggle">
                            <i class="fas fa-moon"></i>
                        </button>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero-section">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <div class="hero-content">
                        <h1 class="animate__animated animate__fadeInUp">Transform Your Vision Into Reality</h1>
                        <p class="animate__animated animate__fadeInUp animate__delay-1s">
                            Professional audio and video production services for artists, creators, and brands worldwide.
                        </p>
                        <div class="animate__animated animate__fadeInUp animate__delay-2s">
                            <a href="services.php" class="btn btn-light btn-lg me-3">
                                <i class="fas fa-rocket me-2"></i>Explore Services
                            </a>
                            <a href="contact.php" class="btn btn-outline-light btn-lg">
                                <i class="fas fa-envelope me-2"></i>Get In Touch
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 d-none d-lg-block">
                    <div class="text-center">
                        <i class="fas fa-video fa-10x opacity-75"></i>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Stats Section -->
    <section class="stats-section">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-6">
                    <div class="stat-item">
                        <div class="stat-number">500+</div>
                        <p class="text-muted">Projects Completed</p>
                    </div>
                </div>
                <div class="col-md-3 col-6">
                    <div class="stat-item">
                        <div class="stat-number">300+</div>
                        <p class="text-muted">Happy Clients</p>
                    </div>
                </div>
                <div class="col-md-3 col-6">
                    <div class="stat-item">
                        <div class="stat-number">15+</div>
                        <p class="text-muted">Years Experience</p>
                    </div>
                </div>
                <div class="col-md-3 col-6">
                    <div class="stat-item">
                        <div class="stat-number">50+</div>
                        <p class="text-muted">Awards Won</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Featured Services -->
    <section class="py-5">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="fw-bold">Our Services</h2>
                <p class="text-muted">Discover our professional audio and video production services</p>
            </div>
            
            <div class="row">
                <?php
                $services_query = "SELECT * FROM services WHERE status = 'active' LIMIT 6";
                $services_result = $conn->query($services_query);
                
                if ($services_result && $services_result->num_rows > 0):
                    while ($service = $services_result->fetch_assoc()):
                ?>
                <div class="col-md-4 col-sm-6 mb-4">
                    <div class="card service-card">
                        <div class="card-body">
                            <div class="text-center mb-3">
                                <i class="fas fa-headphones fa-3x text-primary"></i>
                            </div>
                            <h5 class="card-title fw-bold"><?php echo htmlspecialchars($service['title']); ?></h5>
                            <p class="card-text text-muted"><?php echo htmlspecialchars($service['short_description']); ?></p>
                            <div class="d-flex justify-content-between align-items-center">
                                <span class="badge bg-primary"><?php echo ucfirst($service['price_model']); ?></span>
                                <span class="fw-bold text-primary">₹<?php echo number_format($service['base_price'], 0); ?>+</span>
                            </div>
                            <a href="service-detail.php?slug=<?php echo $service['slug']; ?>" class="btn btn-outline-primary w-100 mt-3">
                                View Details <i class="fas fa-arrow-right ms-2"></i>
                            </a>
                        </div>
                    </div>
                </div>
                <?php 
                    endwhile;
                endif;
                ?>
            </div>
            
            <div class="text-center mt-4">
                <a href="services.php" class="btn btn-primary btn-lg">View All Services</a>
            </div>
        </div>
    </section>

    <!-- Testimonials Section -->
    <section class="py-5 bg-light">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="fw-bold">What Our Clients Say</h2>
                <p class="text-muted">Trusted by artists and creators worldwide</p>
            </div>
            
            <div class="row">
                <?php
                $testimonials_query = "SELECT * FROM testimonials WHERE status = 'approved' ORDER BY display_order LIMIT 3";
                $testimonials_result = $conn->query($testimonials_query);
                
                if ($testimonials_result && $testimonials_result->num_rows > 0):
                    while ($testimonial = $testimonials_result->fetch_assoc()):
                ?>
                <div class="col-md-4 mb-4">
                    <div class="testimonial-card">
                        <div class="mb-3">
                            <?php for($i = 0; $i < $testimonial['rating']; $i++): ?>
                                <i class="fas fa-star text-warning"></i>
                            <?php endfor; ?>
                        </div>
                        <p class="fst-italic">"<?php echo htmlspecialchars($testimonial['message']); ?>"</p>
                        <div class="mt-3">
                            <p class="mb-0 fw-bold"><?php echo htmlspecialchars($testimonial['name']); ?></p>
                            <?php if ($testimonial['company']): ?>
                                <small class="text-muted"><?php echo htmlspecialchars($testimonial['company']); ?></small>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php 
                    endwhile;
                else:
                ?>
                <div class="col-12 text-center">
                    <p class="text-muted">No testimonials available yet.</p>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section class="py-5 bg-primary text-white">
        <div class="container text-center">
            <h2 class="fw-bold mb-3">Ready to Start Your Project?</h2>
            <p class="lead mb-4">Join hundreds of satisfied clients and bring your creative vision to life</p>
            <?php if (isLoggedIn()): ?>
                <a href="submit-project.php" class="btn btn-light btn-lg">
                    <i class="fas fa-plus me-2"></i>Submit Project
                </a>
            <?php else: ?>
                <a href="signup.php" class="btn btn-light btn-lg me-3">
                    <i class="fas fa-user-plus me-2"></i>Sign Up Now
                </a>
                <a href="contact.php" class="btn btn-outline-light btn-lg">
                    <i class="fas fa-envelope me-2"></i>Contact Us
                </a>
            <?php endif; ?>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-4 mb-4">
                    <h5 class="fw-bold mb-3"><?php echo SITE_NAME; ?></h5>
                    <p>Professional audio and video production services for artists, creators, and brands worldwide.</p>
                    <div class="mt-3">
                        <a href="#" class="text-white me-3"><i class="fab fa-facebook fa-lg"></i></a>
                        <a href="#" class="text-white me-3"><i class="fab fa-instagram fa-lg"></i></a>
                        <a href="#" class="text-white me-3"><i class="fab fa-twitter fa-lg"></i></a>
                        <a href="#" class="text-white"><i class="fab fa-youtube fa-lg"></i></a>
                    </div>
                </div>
                <div class="col-md-2 mb-4">
                    <h6 class="fw-bold mb-3">Quick Links</h6>
                    <ul class="list-unstyled">
                        <li><a href="index.php" class="text-white-50">Home</a></li>
                        <li><a href="services.php" class="text-white-50">Services</a></li>
                        <li><a href="portfolio.php" class="text-white-50">Portfolio</a></li>
                        <li><a href="contact.php" class="text-white-50">Contact</a></li>
                    </ul>
                </div>
                <div class="col-md-3 mb-4">
                    <h6 class="fw-bold mb-3">Services</h6>
                    <ul class="list-unstyled">
                        <li><a href="#" class="text-white-50">Audio Mastering</a></li>
                        <li><a href="#" class="text-white-50">Video Editing</a></li>
                        <li><a href="#" class="text-white-50">Music Production</a></li>
                        <li><a href="#" class="text-white-50">Color Grading</a></li>
                    </ul>
                </div>
                <div class="col-md-3 mb-4">
                    <h6 class="fw-bold mb-3">Contact Info</h6>
                    <p class="text-white-50 mb-2"><i class="fas fa-envelope me-2"></i>contact@rsfilmsgroup.com</p>
                    <p class="text-white-50 mb-2"><i class="fas fa-phone me-2"></i>+91 1234567890</p>
                    <p class="text-white-50"><i class="fas fa-map-marker-alt me-2"></i>Mumbai, India</p>
                </div>
            </div>
            <hr class="bg-white">
            <div class="text-center py-3">
                <p class="mb-0">&copy; <?php echo date('Y'); ?> <?php echo SITE_NAME; ?>. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <!-- Mobile Bottom Navigation -->
    <div class="mobile-bottom-nav">
        <div class="container-fluid">
            <div class="row">
                <div class="col-3">
                    <a href="index.php" class="mobile-nav-item active d-block">
                        <i class="fas fa-home"></i>
                        <div>Home</div>
                    </a>
                </div>
                <div class="col-3">
                    <a href="services.php" class="mobile-nav-item d-block">
                        <i class="fas fa-th-large"></i>
                        <div>Services</div>
                    </a>
                </div>
                <div class="col-3">
                    <a href="<?php echo isLoggedIn() ? 'my-projects.php' : 'login.php'; ?>" class="mobile-nav-item d-block">
                        <i class="fas fa-folder"></i>
                        <div>Projects</div>
                    </a>
                </div>
                <div class="col-3">
                    <a href="<?php echo isLoggedIn() ? 'profile.php' : 'login.php'; ?>" class="mobile-nav-item d-block">
                        <i class="fas fa-user"></i>
                        <div>Profile</div>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- MDBootstrap JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.4.2/mdb.min.js"></script>
    
    <script>
        // Theme toggle
        const themeToggle = document.getElementById('theme-toggle');
        const htmlElement = document.documentElement;
        
        // Load saved theme
        const savedTheme = localStorage.getItem('theme') || 'light';
        htmlElement.setAttribute('data-mdb-theme', savedTheme);
        updateThemeIcon(savedTheme);
        
        themeToggle.addEventListener('click', () => {
            const currentTheme = htmlElement.getAttribute('data-mdb-theme');
            const newTheme = currentTheme === 'light' ? 'dark' : 'light';
            
            htmlElement.setAttribute('data-mdb-theme', newTheme);
            localStorage.setItem('theme', newTheme);
            updateThemeIcon(newTheme);
        });
        
        function updateThemeIcon(theme) {
            const icon = themeToggle.querySelector('i');
            icon.className = theme === 'light' ? 'fas fa-moon' : 'fas fa-sun';
        }
    </script>
</body>
</html>
