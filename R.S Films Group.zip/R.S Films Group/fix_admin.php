<?php
// ONE-CLICK ADMIN FIX
// Run this file ONCE to fix admin login issue

error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<!DOCTYPE html>
<html>
<head>
    <title>Admin Account Fix</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 800px; margin: 50px auto; padding: 20px; background: #f5f5f5; }
        .box { background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .success { color: #28a745; font-weight: bold; }
        .error { color: #dc3545; font-weight: bold; }
        .info { color: #1976d2; }
        button { padding: 15px 30px; background: #1976d2; color: white; border: none; border-radius: 5px; cursor: pointer; font-size: 16px; }
        button:hover { background: #1565c0; }
        .credentials { background: #e3f2fd; padding: 15px; border-left: 4px solid #1976d2; margin: 20px 0; }
        a.btn { display: inline-block; padding: 12px 24px; background: #28a745; color: white; text-decoration: none; border-radius: 5px; margin: 10px 5px; }
        a.btn:hover { background: #218838; }
    </style>
</head>
<body>
<div class='box'>";

echo "<h1>🔧 Admin Account Fix</h1>";
echo "<p>This will create/reset your admin account with correct password.</p>";
echo "<hr>";

// Include config
if (!file_exists('config.php')) {
    echo "<p class='error'>❌ config.php not found!</p>";
    echo "<p>Make sure you're running this from the main folder.</p>";
    echo "</div></body></html>";
    exit;
}

require_once 'config.php';

// Check database connection
if ($conn->connect_error) {
    echo "<p class='error'>❌ Database connection failed: " . $conn->connect_error . "</p>";
    echo "<p>Please check your database settings in config.php</p>";
    echo "</div></body></html>";
    exit;
}

echo "<p class='success'>✅ Database connected successfully</p>";

// Check if admins table exists
$result = $conn->query("SHOW TABLES LIKE 'admins'");
if (!$result || $result->num_rows === 0) {
    echo "<p class='error'>❌ Admins table doesn't exist!</p>";
    echo "<p>Please import database.sql first:</p>";
    echo "<ol>
        <li>Open phpMyAdmin: <a href='http://localhost/phpmyadmin' target='_blank'>http://localhost/phpmyadmin</a></li>
        <li>Click 'Import' tab</li>
        <li>Choose file: database.sql</li>
        <li>Click 'Go'</li>
        <li>Then run this page again</li>
    </ol>";
    echo "</div></body></html>";
    exit;
}

echo "<p class='success'>✅ Admins table exists</p>";

// Now fix the admin account
echo "<h2>Fixing Admin Account...</h2>";

// Delete old admin if exists
$conn->query("DELETE FROM admins WHERE email = 'admin@rsfilmsgroup.com'");

// Create new admin with correct password
$name = 'Super Admin';
$email = 'admin@rsfilmsgroup.com';
$password = 'admin123';
$hashed_password = password_hash($password, PASSWORD_DEFAULT);
$role = 'super_admin';
$status = 'active';

$stmt = $conn->prepare("INSERT INTO admins (name, email, password, role, status) VALUES (?, ?, ?, ?, ?)");
if (!$stmt) {
    echo "<p class='error'>❌ Prepare failed: " . $conn->error . "</p>";
    echo "</div></body></html>";
    exit;
}

$stmt->bind_param("sssss", $name, $email, $hashed_password, $role, $status);

if ($stmt->execute()) {
    echo "<p class='success'>✅ SUCCESS! Admin account created!</p>";
    
    echo "<div class='credentials'>";
    echo "<h3>🔑 Login Credentials</h3>";
    echo "<p><strong>Email:</strong> admin@rsfilmsgroup.com</p>";
    echo "<p><strong>Password:</strong> admin123</p>";
    echo "<p style='color: #dc3545;'><strong>⚠️ IMPORTANT:</strong> Change this password after logging in!</p>";
    echo "</div>";
    
    // Verify it works
    echo "<h3>Verifying...</h3>";
    $verify = $conn->query("SELECT id, name, email, role FROM admins WHERE email = 'admin@rsfilmsgroup.com'");
    if ($verify && $verify->num_rows > 0) {
        $admin = $verify->fetch_assoc();
        echo "<p class='success'>✅ Admin account verified in database:</p>";
        echo "<ul>";
        echo "<li>Name: " . htmlspecialchars($admin['name']) . "</li>";
        echo "<li>Email: " . htmlspecialchars($admin['email']) . "</li>";
        echo "<li>Role: " . htmlspecialchars($admin['role']) . "</li>";
        echo "</ul>";
    }
    
    echo "<h3>Next Steps:</h3>";
    echo "<ol>";
    echo "<li>Click the button below to go to admin login</li>";
    echo "<li>Use the credentials shown above</li>";
    echo "<li>Change your password after login</li>";
    echo "<li>Delete this fix_admin.php file</li>";
    echo "</ol>";
    
    echo "<a href='admin/login.php' class='btn'>🚀 Go to Admin Login</a>";
    echo "<a href='index.php' class='btn' style='background: #17a2b8;'>🏠 Go to Home</a>";
    
} else {
    echo "<p class='error'>❌ Failed to create admin: " . $stmt->error . "</p>";
}

$stmt->close();
$conn->close();

echo "</div></body></html>";
?>
