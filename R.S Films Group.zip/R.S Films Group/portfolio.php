<?php require_once 'config.php'; ?>
<!DOCTYPE html>
<html lang="en" data-mdb-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Portfolio - <?php echo SITE_NAME; ?></title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.4.2/mdb.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root { --primary-color: #1976d2; }
        .page-header { background: linear-gradient(135deg, var(--primary-color) 0%, #1565c0 100%); color: white; padding: 80px 0; }
        .portfolio-item { position: relative; overflow: hidden; border-radius: 10px; cursor: pointer; }
        .portfolio-item img { transition: transform 0.3s; width: 100%; height: 250px; object-fit: cover; }
        .portfolio-item:hover img { transform: scale(1.1); }
        .portfolio-overlay { position: absolute; top: 0; left: 0; right: 0; bottom: 0; background: rgba(25, 118, 210, 0.9); color: white; display: flex; align-items: center; justify-content: center; opacity: 0; transition: opacity 0.3s; }
        .portfolio-item:hover .portfolio-overlay { opacity: 1; }
        [data-mdb-theme="dark"] .page-header { background: linear-gradient(135deg, #0d47a1 0%, #01579b 100%); }
        @media (max-width: 768px) { .page-header { padding: 60px 0; } }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light shadow-sm sticky-top">
        <div class="container">
            <a class="navbar-brand fw-bold" href="index.php"><i class="fas fa-film me-2"></i><?php echo SITE_NAME; ?></a>
            <button class="navbar-toggler" type="button" data-mdb-toggle="collapse" data-mdb-target="#navbarNav"><i class="fas fa-bars"></i></button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto align-items-center">
                    <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="services.php">Services</a></li>
                    <li class="nav-item"><a class="nav-link active" href="portfolio.php">Portfolio</a></li>
                    <li class="nav-item"><a class="nav-link" href="contact.php">Contact</a></li>
                    <?php if (isLoggedIn()): ?>
                        <li class="nav-item"><a class="nav-link" href="dashboard.php">Dashboard</a></li>
                    <?php else: ?>
                        <li class="nav-item"><a class="btn btn-primary btn-sm ms-2" href="login.php">Login</a></li>
                    <?php endif; ?>
                    <li class="nav-item ms-2">
                        <button class="btn btn-sm btn-outline-secondary" id="theme-toggle"><i class="fas fa-moon"></i></button>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="page-header">
        <div class="container text-center">
            <h1 class="fw-bold display-4 mb-3">Our Portfolio</h1>
            <p class="lead">Explore our recent projects and creative work</p>
        </div>
    </div>

    <div class="container my-5">
        <div class="row">
            <?php for($i = 1; $i <= 6; $i++): ?>
            <div class="col-md-4 mb-4">
                <div class="portfolio-item">
                    <div class="bg-primary text-white d-flex align-items-center justify-content-center" style="height: 250px;">
                        <i class="fas fa-video fa-4x"></i>
                    </div>
                    <div class="portfolio-overlay">
                        <div class="text-center">
                            <h5 class="fw-bold">Project Title <?php echo $i; ?></h5>
                            <p>Audio/Video Production</p>
                            <button class="btn btn-light btn-sm">View Details</button>
                        </div>
                    </div>
                </div>
            </div>
            <?php endfor; ?>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.4.2/mdb.min.js"></script>
    <script>
        const themeToggle = document.getElementById('theme-toggle');
        const htmlElement = document.documentElement;
        const savedTheme = localStorage.getItem('theme') || 'light';
        htmlElement.setAttribute('data-mdb-theme', savedTheme);
        themeToggle.querySelector('i').className = savedTheme === 'light' ? 'fas fa-moon' : 'fas fa-sun';
        themeToggle.addEventListener('click', () => {
            const currentTheme = htmlElement.getAttribute('data-mdb-theme');
            const newTheme = currentTheme === 'light' ? 'dark' : 'light';
            htmlElement.setAttribute('data-mdb-theme', newTheme);
            localStorage.setItem('theme', newTheme);
            themeToggle.querySelector('i').className = newTheme === 'light' ? 'fas fa-moon' : 'fas fa-sun';
        });
    </script>
</body>
</html>
