-- R.S Films Group Database Schema
-- Create database
CREATE DATABASE IF NOT EXISTS rs_films_group CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE rs_films_group;

-- Users table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    phone VARCHAR(20),
    company VARCHAR(255),
    status ENUM('active', 'blocked') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Admins table
CREATE TABLE IF NOT EXISTS admins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('super_admin', 'editor') DEFAULT 'editor',
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Services table
CREATE TABLE IF NOT EXISTS services (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    slug VARCHAR(255) UNIQUE NOT NULL,
    description TEXT,
    short_description VARCHAR(500),
    category VARCHAR(100),
    price_model ENUM('fixed', 'hourly', 'project_based', 'custom') DEFAULT 'custom',
    base_price DECIMAL(10,2) DEFAULT 0,
    image VARCHAR(255),
    features TEXT,
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Projects table
CREATE TABLE IF NOT EXISTS projects (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    service_id INT,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    project_type VARCHAR(100),
    status ENUM('pending', 'in_progress', 'review', 'completed', 'cancelled') DEFAULT 'pending',
    priority ENUM('low', 'medium', 'high') DEFAULT 'medium',
    deadline DATE,
    total_cost DECIMAL(10,2) DEFAULT 0,
    paid_amount DECIMAL(10,2) DEFAULT 0,
    balance DECIMAL(10,2) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (service_id) REFERENCES services(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Project files table
CREATE TABLE IF NOT EXISTS project_files (
    id INT AUTO_INCREMENT PRIMARY KEY,
    project_id INT NOT NULL,
    file_name VARCHAR(255) NOT NULL,
    original_name VARCHAR(255) NOT NULL,
    file_path VARCHAR(500) NOT NULL,
    file_type VARCHAR(50),
    file_size INT,
    uploaded_by ENUM('user', 'admin') DEFAULT 'user',
    category ENUM('source', 'master', 'reference', 'other') DEFAULT 'source',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Project metadata table (for ISRC, release dates, etc.)
CREATE TABLE IF NOT EXISTS project_metadata (
    id INT AUTO_INCREMENT PRIMARY KEY,
    project_id INT NOT NULL UNIQUE,
    isrc VARCHAR(50),
    song_title VARCHAR(255),
    artist_name VARCHAR(255),
    album_name VARCHAR(255),
    release_date DATE,
    genre VARCHAR(100),
    label VARCHAR(255),
    additional_info TEXT,
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Finance ledger table
CREATE TABLE IF NOT EXISTS finance_ledger (
    id INT AUTO_INCREMENT PRIMARY KEY,
    project_id INT NOT NULL,
    user_id INT NOT NULL,
    transaction_type ENUM('credit', 'debit', 'invoice', 'payment') DEFAULT 'invoice',
    amount DECIMAL(10,2) NOT NULL,
    description TEXT,
    payment_method VARCHAR(50),
    transaction_id VARCHAR(100),
    status ENUM('pending', 'completed', 'failed', 'refunded') DEFAULT 'pending',
    transaction_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Coupons table
CREATE TABLE IF NOT EXISTS coupons (
    id INT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(50) UNIQUE NOT NULL,
    type ENUM('flat', 'percentage') DEFAULT 'flat',
    value DECIMAL(10,2) NOT NULL,
    min_order_amount DECIMAL(10,2) DEFAULT 0,
    max_discount DECIMAL(10,2),
    usage_limit INT DEFAULT 0,
    used_count INT DEFAULT 0,
    expires_at DATETIME,
    status ENUM('active', 'inactive', 'expired') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Coupon usage table
CREATE TABLE IF NOT EXISTS coupon_usage (
    id INT AUTO_INCREMENT PRIMARY KEY,
    coupon_id INT NOT NULL,
    user_id INT NOT NULL,
    project_id INT,
    discount_amount DECIMAL(10,2),
    used_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (coupon_id) REFERENCES coupons(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Support tickets table
CREATE TABLE IF NOT EXISTS support_tickets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    subject VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    status ENUM('open', 'in_progress', 'resolved', 'closed') DEFAULT 'open',
    priority ENUM('low', 'medium', 'high') DEFAULT 'medium',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Support ticket replies table
CREATE TABLE IF NOT EXISTS ticket_replies (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ticket_id INT NOT NULL,
    replied_by ENUM('user', 'admin') DEFAULT 'admin',
    reply_text TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (ticket_id) REFERENCES support_tickets(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- FAQ table
CREATE TABLE IF NOT EXISTS faqs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    question VARCHAR(500) NOT NULL,
    answer TEXT NOT NULL,
    category VARCHAR(100),
    display_order INT DEFAULT 0,
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Testimonials table
CREATE TABLE IF NOT EXISTS testimonials (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    name VARCHAR(255) NOT NULL,
    company VARCHAR(255),
    message TEXT NOT NULL,
    rating INT DEFAULT 5,
    image VARCHAR(255),
    status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
    display_order INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Settings table
CREATE TABLE IF NOT EXISTS settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    setting_key VARCHAR(100) UNIQUE NOT NULL,
    setting_value TEXT,
    setting_type VARCHAR(50) DEFAULT 'text',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Password reset tokens table
CREATE TABLE IF NOT EXISTS password_resets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) NOT NULL,
    token VARCHAR(255) NOT NULL,
    expires_at DATETIME NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX (email),
    INDEX (token)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insert default admin account
INSERT INTO admins (name, email, password, role, status) VALUES 
('Super Admin', 'admin@rsfilmsgroup.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'super_admin', 'active');
-- Default password: admin123 (MUST be changed after first login)

-- Insert default settings
INSERT INTO settings (setting_key, setting_value, setting_type) VALUES
('site_name', 'R.S Films Group', 'text'),
('site_logo', '', 'text'),
('site_email', 'contact@rsfilmsgroup.com', 'text'),
('site_phone', '+91 1234567890', 'text'),
('payment_gateway', 'razorpay', 'text'),
('razorpay_key_id', '', 'text'),
('razorpay_key_secret', '', 'text'),
('stripe_public_key', '', 'text'),
('stripe_secret_key', '', 'text'),
('paypal_client_id', '', 'text'),
('paypal_client_secret', '', 'text'),
('tax_percentage', '18', 'number'),
('currency_symbol', '₹', 'text'),
('enable_notifications', '1', 'boolean'),
('theme_mode', 'light', 'text');

-- Insert sample services
INSERT INTO services (title, slug, description, short_description, category, price_model, base_price, status) VALUES
('Audio Mastering', 'audio-mastering', 'Professional audio mastering services for your music tracks. We enhance the clarity, depth, and overall sound quality of your recordings.', 'Professional audio mastering services', 'Audio', 'project_based', 5000.00, 'active'),
('Video Editing', 'video-editing', 'High-quality video editing services including color grading, transitions, effects, and professional post-production.', 'Professional video editing services', 'Video', 'hourly', 2000.00, 'active'),
('Music Production', 'music-production', 'Complete music production services from composition to final mix. Perfect for artists and content creators.', 'Complete music production services', 'Audio', 'custom', 15000.00, 'active'),
('Color Grading', 'color-grading', 'Professional color grading and color correction services to give your videos a cinematic look.', 'Professional color grading services', 'Video', 'project_based', 8000.00, 'active'),
('Sound Design', 'sound-design', 'Custom sound design for films, videos, and multimedia projects. Create immersive audio experiences.', 'Custom sound design services', 'Audio', 'project_based', 10000.00, 'active'),
('Motion Graphics', 'motion-graphics', 'Stunning motion graphics and animation services for your video projects and brand identity.', 'Motion graphics and animation', 'Video', 'project_based', 12000.00, 'active');

-- Insert sample FAQs
INSERT INTO faqs (question, answer, category, display_order, status) VALUES
('What services do you offer?', 'We offer a complete range of audio and video production services including audio mastering, video editing, music production, color grading, sound design, and motion graphics.', 'General', 1, 'active'),
('How do I submit a project?', 'After creating an account, log in to your dashboard and navigate to the "Submit Project" page. Fill in the details and upload your files. Our team will review and contact you within 24 hours.', 'Projects', 2, 'active'),
('What payment methods do you accept?', 'We accept payments via Razorpay, PayPal, and Stripe. You can pay using credit/debit cards, UPI, net banking, and digital wallets.', 'Payment', 3, 'active'),
('How long does it take to complete a project?', 'Project completion time varies based on the service type and complexity. Typically, audio mastering takes 2-3 days, while video editing can take 5-7 days. Timelines are discussed during project initiation.', 'Projects', 4, 'active'),
('Can I request revisions?', 'Yes, we offer up to 2 free revisions for all projects. Additional revisions may incur extra charges depending on the scope of changes.', 'Projects', 5, 'active');
