<?php
require_once 'config.php';

if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$project_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Get project details
$stmt = $conn->prepare("SELECT p.*, s.title as service_title, s.category as service_category
                        FROM projects p 
                        LEFT JOIN services s ON p.service_id = s.id 
                        WHERE p.id = ? AND p.user_id = ?");
$stmt->bind_param("ii", $project_id, $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    header('Location: my-projects.php');
    exit;
}

$project = $result->fetch_assoc();

// Get project metadata
$stmt = $conn->prepare("SELECT * FROM project_metadata WHERE project_id = ?");
$stmt->bind_param("i", $project_id);
$stmt->execute();
$metadata = $stmt->get_result()->fetch_assoc();

// Get project files
$stmt = $conn->prepare("SELECT * FROM project_files WHERE project_id = ? ORDER BY created_at DESC");
$stmt->bind_param("i", $project_id);
$stmt->execute();
$files = $stmt->get_result();

// Get transactions
$stmt = $conn->prepare("SELECT * FROM finance_ledger WHERE project_id = ? ORDER BY transaction_date DESC");
$stmt->bind_param("i", $project_id);
$stmt->execute();
$transactions = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en" data-mdb-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($project['title']); ?> - <?php echo SITE_NAME; ?></title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.4.2/mdb.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root { --primary-color: #1976d2; }
        .page-header { background: linear-gradient(135deg, var(--primary-color) 0%, #1565c0 100%); color: white; padding: 60px 0; }
        .status-badge { font-size: 1rem; padding: 8px 16px; }
        .info-card { border-left: 4px solid var(--primary-color); }
        .file-item { padding: 15px; border: 1px solid #eee; border-radius: 8px; margin-bottom: 10px; transition: all 0.3s; }
        .file-item:hover { background: #f8f9fa; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
        [data-mdb-theme="dark"] .page-header { background: linear-gradient(135deg, #0d47a1 0%, #01579b 100%); }
        [data-mdb-theme="dark"] .file-item { border-color: #333; background: #1e1e1e; }
        [data-mdb-theme="dark"] .file-item:hover { background: #2a2a2a; }
        @media (max-width: 768px) { .page-header { padding: 40px 0; } }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light shadow-sm sticky-top">
        <div class="container">
            <a class="navbar-brand fw-bold" href="index.php"><i class="fas fa-film me-2"></i><?php echo SITE_NAME; ?></a>
            <button class="navbar-toggler" type="button" data-mdb-toggle="collapse" data-mdb-target="#navbarNav"><i class="fas fa-bars"></i></button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto align-items-center">
                    <li class="nav-item"><a class="nav-link" href="dashboard.php">Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link active" href="my-projects.php">My Projects</a></li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-mdb-toggle="dropdown">
                            <i class="fas fa-user-circle"></i> <?php echo htmlspecialchars($_SESSION['user_name']); ?>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="profile.php">Profile</a></li>
                            <li><a class="dropdown-item" href="logout.php">Logout</a></li>
                        </ul>
                    </li>
                    <li class="nav-item ms-2">
                        <button class="btn btn-sm btn-outline-secondary" id="theme-toggle"><i class="fas fa-moon"></i></button>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="page-header">
        <div class="container">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb text-white mb-3">
                    <li class="breadcrumb-item"><a href="dashboard.php" class="text-white">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="my-projects.php" class="text-white">My Projects</a></li>
                    <li class="breadcrumb-item active text-white"><?php echo htmlspecialchars($project['title']); ?></li>
                </ol>
            </nav>
            <div class="d-flex justify-content-between align-items-center flex-wrap">
                <div>
                    <h1 class="fw-bold mb-2"><?php echo htmlspecialchars($project['title']); ?></h1>
                    <p class="mb-0"><i class="fas fa-briefcase me-2"></i><?php echo htmlspecialchars($project['service_title'] ?? 'N/A'); ?></p>
                </div>
                <div>
                    <?php
                    $badge_class = ['pending' => 'warning', 'in_progress' => 'info', 'review' => 'primary', 'completed' => 'success', 'cancelled' => 'danger'];
                    $status_class = $badge_class[$project['status']] ?? 'secondary';
                    ?>
                    <span class="badge bg-<?php echo $status_class; ?> status-badge">
                        <?php echo ucfirst(str_replace('_', ' ', $project['status'])); ?>
                    </span>
                </div>
            </div>
        </div>
    </div>

    <div class="container my-5">
        <div class="row">
            <div class="col-lg-8 mb-4">
                <!-- Project Details -->
                <div class="card mb-4">
                    <div class="card-body">
                        <h5 class="card-title fw-bold mb-3">Project Details</h5>
                        <p class="text-muted"><?php echo nl2br(htmlspecialchars($project['description'])); ?></p>
                        
                        <div class="row mt-4">
                            <div class="col-md-6 mb-3">
                                <p class="text-muted mb-1"><i class="fas fa-tag me-2"></i>Project Type</p>
                                <p class="fw-bold"><?php echo htmlspecialchars($project['project_type'] ?? 'N/A'); ?></p>
                            </div>
                            <div class="col-md-6 mb-3">
                                <p class="text-muted mb-1"><i class="fas fa-calendar me-2"></i>Deadline</p>
                                <p class="fw-bold"><?php echo $project['deadline'] ? date('M d, Y', strtotime($project['deadline'])) : 'Not set'; ?></p>
                            </div>
                            <div class="col-md-6 mb-3">
                                <p class="text-muted mb-1"><i class="fas fa-clock me-2"></i>Created</p>
                                <p class="fw-bold"><?php echo date('M d, Y', strtotime($project['created_at'])); ?></p>
                            </div>
                            <div class="col-md-6 mb-3">
                                <p class="text-muted mb-1"><i class="fas fa-sync me-2"></i>Last Updated</p>
                                <p class="fw-bold"><?php echo date('M d, Y', strtotime($project['updated_at'])); ?></p>
                            </div>
                        </div>
                    </div>
                </div>

                <?php if ($metadata): ?>
                <!-- Project Metadata -->
                <div class="card mb-4">
                    <div class="card-body">
                        <h5 class="card-title fw-bold mb-3">Project Metadata</h5>
                        <div class="row">
                            <?php if ($metadata['isrc']): ?>
                            <div class="col-md-6 mb-3">
                                <p class="text-muted mb-1">ISRC Code</p>
                                <p class="fw-bold"><?php echo htmlspecialchars($metadata['isrc']); ?></p>
                            </div>
                            <?php endif; ?>
                            <?php if ($metadata['song_title']): ?>
                            <div class="col-md-6 mb-3">
                                <p class="text-muted mb-1">Song Title</p>
                                <p class="fw-bold"><?php echo htmlspecialchars($metadata['song_title']); ?></p>
                            </div>
                            <?php endif; ?>
                            <?php if ($metadata['artist_name']): ?>
                            <div class="col-md-6 mb-3">
                                <p class="text-muted mb-1">Artist Name</p>
                                <p class="fw-bold"><?php echo htmlspecialchars($metadata['artist_name']); ?></p>
                            </div>
                            <?php endif; ?>
                            <?php if ($metadata['album_name']): ?>
                            <div class="col-md-6 mb-3">
                                <p class="text-muted mb-1">Album Name</p>
                                <p class="fw-bold"><?php echo htmlspecialchars($metadata['album_name']); ?></p>
                            </div>
                            <?php endif; ?>
                            <?php if ($metadata['release_date']): ?>
                            <div class="col-md-6 mb-3">
                                <p class="text-muted mb-1">Release Date</p>
                                <p class="fw-bold"><?php echo date('M d, Y', strtotime($metadata['release_date'])); ?></p>
                            </div>
                            <?php endif; ?>
                            <?php if ($metadata['genre']): ?>
                            <div class="col-md-6 mb-3">
                                <p class="text-muted mb-1">Genre</p>
                                <p class="fw-bold"><?php echo htmlspecialchars($metadata['genre']); ?></p>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Project Files -->
                <div class="card mb-4">
                    <div class="card-body">
                        <h5 class="card-title fw-bold mb-3">Project Files</h5>
                        
                        <?php if ($files->num_rows > 0): ?>
                            <?php while ($file = $files->fetch_assoc()): ?>
                            <div class="file-item">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <i class="fas fa-file fa-2x text-primary me-3"></i>
                                        <strong><?php echo htmlspecialchars($file['original_name']); ?></strong>
                                        <br>
                                        <small class="text-muted ms-5">
                                            <?php echo round($file['file_size'] / 1024 / 1024, 2); ?> MB • 
                                            Uploaded <?php echo date('M d, Y', strtotime($file['created_at'])); ?> • 
                                            <?php echo ucfirst($file['category']); ?>
                                        </small>
                                    </div>
                                    <div>
                                        <?php if ($file['category'] === 'master' || $project['status'] === 'completed'): ?>
                                        <a href="<?php echo htmlspecialchars($file['file_path']); ?>" download class="btn btn-primary btn-sm">
                                            <i class="fas fa-download me-2"></i>Download
                                        </a>
                                        <?php else: ?>
                                        <span class="badge bg-secondary">Source File</span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <div class="text-center py-4">
                                <i class="fas fa-folder-open fa-3x text-muted mb-3"></i>
                                <p class="text-muted">No files uploaded yet</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Transactions -->
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title fw-bold mb-3">Transaction History</h5>
                        
                        <?php if ($transactions->num_rows > 0): ?>
                            <?php while ($transaction = $transactions->fetch_assoc()): ?>
                            <div class="d-flex justify-content-between align-items-center mb-3 pb-3 border-bottom">
                                <div>
                                    <h6 class="mb-1"><?php echo htmlspecialchars($transaction['description']); ?></h6>
                                    <small class="text-muted">
                                        <?php echo date('M d, Y', strtotime($transaction['transaction_date'])); ?> • 
                                        <?php echo ucfirst($transaction['transaction_type']); ?>
                                    </small>
                                </div>
                                <div class="text-end">
                                    <h6 class="mb-0 <?php echo in_array($transaction['transaction_type'], ['credit', 'payment']) ? 'text-success' : 'text-danger'; ?>">
                                        <?php echo in_array($transaction['transaction_type'], ['credit', 'payment']) ? '+' : '-'; ?>
                                        ₹<?php echo number_format($transaction['amount'], 2); ?>
                                    </h6>
                                    <span class="badge bg-<?php echo $transaction['status'] === 'completed' ? 'success' : 'warning'; ?>">
                                        <?php echo ucfirst($transaction['status']); ?>
                                    </span>
                                </div>
                            </div>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <div class="text-center py-4">
                                <i class="fas fa-receipt fa-3x text-muted mb-3"></i>
                                <p class="text-muted">No transactions yet</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <div class="col-lg-4">
                <!-- Project Summary -->
                <div class="card info-card mb-4 sticky-top" style="top: 100px;">
                    <div class="card-body">
                        <h5 class="card-title fw-bold mb-4">Project Summary</h5>
                        
                        <div class="mb-4">
                            <p class="text-muted mb-2">Project Status</p>
                            <span class="badge bg-<?php echo $status_class; ?> status-badge">
                                <?php echo ucfirst(str_replace('_', ' ', $project['status'])); ?>
                            </span>
                        </div>

                        <div class="mb-4">
                            <p class="text-muted mb-2">Total Cost</p>
                            <h4 class="fw-bold text-primary mb-0">₹<?php echo number_format($project['total_cost'], 2); ?></h4>
                        </div>

                        <div class="mb-4">
                            <p class="text-muted mb-2">Paid Amount</p>
                            <h5 class="fw-bold text-success mb-0">₹<?php echo number_format($project['paid_amount'], 2); ?></h5>
                        </div>

                        <?php if ($project['balance'] > 0): ?>
                        <div class="mb-4">
                            <p class="text-muted mb-2">Balance Due</p>
                            <h5 class="fw-bold text-danger mb-0">₹<?php echo number_format($project['balance'], 2); ?></h5>
                        </div>
                        <?php endif; ?>

                        <hr>

                        <div class="d-grid gap-2">
                            <a href="my-projects.php" class="btn btn-outline-primary">
                                <i class="fas fa-arrow-left me-2"></i>Back to Projects
                            </a>
                            <a href="contact.php" class="btn btn-primary">
                                <i class="fas fa-headset me-2"></i>Contact Support
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.4.2/mdb.min.js"></script>
    <script>
        const themeToggle = document.getElementById('theme-toggle');
        const htmlElement = document.documentElement;
        const savedTheme = localStorage.getItem('theme') || 'light';
        htmlElement.setAttribute('data-mdb-theme', savedTheme);
        themeToggle.querySelector('i').className = savedTheme === 'light' ? 'fas fa-moon' : 'fas fa-sun';
        themeToggle.addEventListener('click', () => {
            const currentTheme = htmlElement.getAttribute('data-mdb-theme');
            const newTheme = currentTheme === 'light' ? 'dark' : 'light';
            htmlElement.setAttribute('data-mdb-theme', newTheme);
            localStorage.setItem('theme', newTheme);
            themeToggle.querySelector('i').className = newTheme === 'light' ? 'fas fa-moon' : 'fas fa-sun';
        });
    </script>
</body>
</html>
