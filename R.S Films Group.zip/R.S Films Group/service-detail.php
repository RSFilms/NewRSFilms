<?php
require_once 'config.php';

$slug = $_GET['slug'] ?? '';

if (empty($slug)) {
    header('Location: services.php');
    exit;
}

$stmt = $conn->prepare("SELECT * FROM services WHERE slug = ? AND status = 'active'");
$stmt->bind_param("s", $slug);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    header('Location: services.php');
    exit;
}

$service = $result->fetch_assoc();

// Get related services
$related_query = "SELECT * FROM services WHERE category = ? AND slug != ? AND status = 'active' LIMIT 3";
$related_stmt = $conn->prepare($related_query);
$related_stmt->bind_param("ss", $service['category'], $slug);
$related_stmt->execute();
$related_services = $related_stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en" data-mdb-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($service['title']); ?> - <?php echo SITE_NAME; ?></title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.4.2/mdb.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: #1976d2;
        }
        
        .service-hero {
            background: linear-gradient(135deg, var(--primary-color) 0%, #1565c0 100%);
            color: white;
            padding: 60px 0;
        }
        
        .price-card {
            position: sticky;
            top: 100px;
        }
        
        .feature-item {
            padding: 15px 0;
            border-bottom: 1px solid #eee;
        }
        
        .feature-item:last-child {
            border-bottom: none;
        }
        
        .related-card {
            transition: transform 0.3s;
        }
        
        .related-card:hover {
            transform: translateY(-5px);
        }
        
        [data-mdb-theme="dark"] .service-hero {
            background: linear-gradient(135deg, #0d47a1 0%, #01579b 100%);
        }
        
        [data-mdb-theme="dark"] .feature-item {
            border-bottom-color: #333;
        }
        
        @media (max-width: 768px) {
            .service-hero {
                padding: 40px 0;
            }
            
            .price-card {
                position: static;
            }
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light shadow-sm sticky-top">
        <div class="container">
            <a class="navbar-brand fw-bold" href="index.php">
                <i class="fas fa-film me-2"></i><?php echo SITE_NAME; ?>
            </a>
            
            <button class="navbar-toggler" type="button" data-mdb-toggle="collapse" data-mdb-target="#navbarNav">
                <i class="fas fa-bars"></i>
            </button>
            
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto align-items-center">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="services.php">Services</a>
                    </li>
                    <?php if (isLoggedIn()): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="dashboard.php">Dashboard</a>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="btn btn-primary btn-sm ms-2" href="login.php">Login</a>
                        </li>
                    <?php endif; ?>
                    <li class="nav-item ms-2">
                        <button class="btn btn-sm btn-outline-secondary" id="theme-toggle">
                            <i class="fas fa-moon"></i>
                        </button>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Service Hero -->
    <div class="service-hero">
        <div class="container">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb text-white">
                    <li class="breadcrumb-item"><a href="index.php" class="text-white">Home</a></li>
                    <li class="breadcrumb-item"><a href="services.php" class="text-white">Services</a></li>
                    <li class="breadcrumb-item active text-white"><?php echo htmlspecialchars($service['title']); ?></li>
                </ol>
            </nav>
            <h1 class="fw-bold display-4"><?php echo htmlspecialchars($service['title']); ?></h1>
            <p class="lead"><?php echo htmlspecialchars($service['short_description']); ?></p>
            <div class="mt-3">
                <span class="badge bg-light text-dark me-2"><?php echo htmlspecialchars($service['category']); ?></span>
                <span class="badge bg-light text-dark"><?php echo ucfirst(str_replace('_', ' ', $service['price_model'])); ?></span>
            </div>
        </div>
    </div>

    <!-- Main Content -->
    <div class="container my-5">
        <div class="row">
            <div class="col-lg-8 mb-4">
                <div class="card mb-4">
                    <div class="card-body">
                        <h3 class="fw-bold mb-4">Service Description</h3>
                        <p class="text-muted"><?php echo nl2br(htmlspecialchars($service['description'])); ?></p>
                    </div>
                </div>
                
                <?php if ($service['features']): ?>
                <div class="card">
                    <div class="card-body">
                        <h3 class="fw-bold mb-4">What's Included</h3>
                        <?php 
                        $features = explode("\n", $service['features']);
                        foreach ($features as $feature):
                            if (trim($feature)):
                        ?>
                        <div class="feature-item">
                            <i class="fas fa-check-circle text-success me-3"></i>
                            <span><?php echo htmlspecialchars(trim($feature)); ?></span>
                        </div>
                        <?php 
                            endif;
                        endforeach; 
                        ?>
                    </div>
                </div>
                <?php endif; ?>
            </div>
            
            <div class="col-lg-4">
                <div class="card price-card shadow">
                    <div class="card-body">
                        <div class="text-center mb-4">
                            <h2 class="fw-bold text-primary mb-0">₹<?php echo number_format($service['base_price'], 0); ?>+</h2>
                            <p class="text-muted"><?php echo ucfirst(str_replace('_', ' ', $service['price_model'])); ?></p>
                        </div>
                        
                        <?php if (isLoggedIn()): ?>
                            <a href="submit-project.php?service_id=<?php echo $service['id']; ?>" class="btn btn-primary btn-lg w-100 mb-3">
                                <i class="fas fa-rocket me-2"></i>Start Project
                            </a>
                        <?php else: ?>
                            <a href="login.php?redirect=service-detail.php?slug=<?php echo $slug; ?>" class="btn btn-primary btn-lg w-100 mb-3">
                                <i class="fas fa-sign-in-alt me-2"></i>Login to Start
                            </a>
                        <?php endif; ?>
                        
                        <a href="contact.php" class="btn btn-outline-primary w-100">
                            <i class="fas fa-envelope me-2"></i>Request Quote
                        </a>
                        
                        <hr class="my-4">
                        
                        <div class="mb-3">
                            <h6 class="fw-bold">Need Help?</h6>
                            <p class="text-muted small mb-0">Contact our team for personalized assistance</p>
                        </div>
                        
                        <div class="d-grid gap-2">
                            <a href="contact.php" class="btn btn-sm btn-outline-secondary">
                                <i class="fas fa-phone me-2"></i>Contact Us
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Related Services -->
        <?php if ($related_services->num_rows > 0): ?>
        <div class="mt-5">
            <h3 class="fw-bold mb-4">Related Services</h3>
            <div class="row">
                <?php while ($related = $related_services->fetch_assoc()): ?>
                <div class="col-md-4 mb-4">
                    <div class="card related-card h-100">
                        <div class="card-body">
                            <h5 class="card-title fw-bold"><?php echo htmlspecialchars($related['title']); ?></h5>
                            <p class="card-text text-muted"><?php echo htmlspecialchars($related['short_description']); ?></p>
                            <div class="d-flex justify-content-between align-items-center">
                                <span class="fw-bold text-primary">₹<?php echo number_format($related['base_price'], 0); ?>+</span>
                                <a href="service-detail.php?slug=<?php echo $related['slug']; ?>" class="btn btn-sm btn-primary">
                                    View <i class="fas fa-arrow-right ms-1"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endwhile; ?>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.4.2/mdb.min.js"></script>
    <script>
        const themeToggle = document.getElementById('theme-toggle');
        const htmlElement = document.documentElement;
        const savedTheme = localStorage.getItem('theme') || 'light';
        htmlElement.setAttribute('data-mdb-theme', savedTheme);
        updateThemeIcon(savedTheme);
        
        themeToggle.addEventListener('click', () => {
            const currentTheme = htmlElement.getAttribute('data-mdb-theme');
            const newTheme = currentTheme === 'light' ? 'dark' : 'light';
            htmlElement.setAttribute('data-mdb-theme', newTheme);
            localStorage.setItem('theme', newTheme);
            updateThemeIcon(newTheme);
        });
        
        function updateThemeIcon(theme) {
            const icon = themeToggle.querySelector('i');
            icon.className = theme === 'light' ? 'fas fa-moon' : 'fas fa-sun';
        }
    </script>
</body>
</html>
