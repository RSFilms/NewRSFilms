<?php
// Setup Admin Account Script
// Run this file ONCE after importing the database to create the admin account

require_once 'config.php';

echo "<h2>Admin Account Setup</h2>";

// Check if admin already exists
$check = $conn->query("SELECT COUNT(*) as count FROM admins WHERE email = 'admin@rsfilmsgroup.com'");
$result = $check->fetch_assoc();

if ($result['count'] > 0) {
    echo "<p style='color: orange;'>Admin account already exists. Updating password...</p>";
    
    // Update existing admin password
    $password = 'admin123';
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    
    $stmt = $conn->prepare("UPDATE admins SET password = ? WHERE email = 'admin@rsfilmsgroup.com'");
    $stmt->bind_param("s", $hashed_password);
    
    if ($stmt->execute()) {
        echo "<p style='color: green;'>✓ Admin password updated successfully!</p>";
    } else {
        echo "<p style='color: red;'>✗ Failed to update password: " . $conn->error . "</p>";
    }
} else {
    echo "<p style='color: blue;'>Creating new admin account...</p>";
    
    // Create new admin account
    $name = 'Super Admin';
    $email = 'admin@rsfilmsgroup.com';
    $password = 'admin123';
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    $role = 'super_admin';
    $status = 'active';
    
    $stmt = $conn->prepare("INSERT INTO admins (name, email, password, role, status) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $name, $email, $hashed_password, $role, $status);
    
    if ($stmt->execute()) {
        echo "<p style='color: green;'>✓ Admin account created successfully!</p>";
    } else {
        echo "<p style='color: red;'>✗ Failed to create admin: " . $conn->error . "</p>";
    }
}

echo "<hr>";
echo "<h3>Admin Login Credentials:</h3>";
echo "<p><strong>Email:</strong> admin@rsfilmsgroup.com</p>";
echo "<p><strong>Password:</strong> admin123</p>";
echo "<p style='color: red;'><strong>⚠️ IMPORTANT:</strong> Change this password immediately after logging in!</p>";
echo "<hr>";
echo "<p><a href='admin/login.php' style='padding: 10px 20px; background: #1976d2; color: white; text-decoration: none; border-radius: 5px;'>Go to Admin Login</a></p>";
echo "<p><a href='index.php' style='padding: 10px 20px; background: #28a745; color: white; text-decoration: none; border-radius: 5px;'>Go to Home Page</a></p>";
echo "<hr>";
echo "<p style='color: #666;'><small>After successful login, you can delete this file (setup_admin.php) for security.</small></p>";
?>
