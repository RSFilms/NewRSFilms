<?php
require_once 'config.php';

// Get filter parameters
$search = isset($_GET['search']) ? sanitize($_GET['search']) : '';
$category = isset($_GET['category']) ? sanitize($_GET['category']) : '';
$price_range = isset($_GET['price']) ? sanitize($_GET['price']) : '';

// Build query
$where_clauses = ["status = 'active'"];
$params = [];
$types = '';

if (!empty($search)) {
    $where_clauses[] = "(title LIKE ? OR description LIKE ?)";
    $search_param = "%$search%";
    $params[] = $search_param;
    $params[] = $search_param;
    $types .= 'ss';
}

if (!empty($category)) {
    $where_clauses[] = "category = ?";
    $params[] = $category;
    $types .= 's';
}

if (!empty($price_range)) {
    switch ($price_range) {
        case 'low':
            $where_clauses[] = "base_price < 5000";
            break;
        case 'medium':
            $where_clauses[] = "base_price BETWEEN 5000 AND 15000";
            break;
        case 'high':
            $where_clauses[] = "base_price > 15000";
            break;
    }
}

$where_sql = implode(' AND ', $where_clauses);
$query = "SELECT * FROM services WHERE $where_sql ORDER BY created_at DESC";

if (!empty($params)) {
    $stmt = $conn->prepare($query);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $services_result = $stmt->get_result();
} else {
    $services_result = $conn->query($query);
}

// Get categories for filter
$categories_result = $conn->query("SELECT DISTINCT category FROM services WHERE status = 'active' ORDER BY category");
?>
<!DOCTYPE html>
<html lang="en" data-mdb-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Our Services - <?php echo SITE_NAME; ?></title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.4.2/mdb.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: #1976d2;
        }
        
        .page-header {
            background: linear-gradient(135deg, var(--primary-color) 0%, #1565c0 100%);
            color: white;
            padding: 60px 0;
        }
        
        .filter-section {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 30px;
        }
        
        .service-card {
            transition: transform 0.3s, box-shadow 0.3s;
            height: 100%;
            cursor: pointer;
        }
        
        .service-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(0,0,0,0.15);
        }
        
        [data-mdb-theme="dark"] .page-header {
            background: linear-gradient(135deg, #0d47a1 0%, #01579b 100%);
        }
        
        [data-mdb-theme="dark"] .filter-section {
            background: #1e1e1e;
        }
        
        .mobile-bottom-nav {
            display: none;
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: white;
            box-shadow: 0 -2px 10px rgba(0,0,0,0.1);
            z-index: 1000;
            padding: 10px 0;
        }
        
        .mobile-nav-item {
            text-align: center;
            color: #666;
            text-decoration: none;
            font-size: 0.75rem;
        }
        
        .mobile-nav-item i {
            font-size: 1.5rem;
            display: block;
            margin-bottom: 5px;
        }
        
        .mobile-nav-item.active {
            color: var(--primary-color);
        }
        
        @media (max-width: 768px) {
            .mobile-bottom-nav {
                display: flex;
            }
            
            body {
                padding-bottom: 70px;
            }
            
            .page-header {
                padding: 40px 0;
            }
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light shadow-sm sticky-top">
        <div class="container">
            <a class="navbar-brand fw-bold" href="index.php">
                <i class="fas fa-film me-2"></i><?php echo SITE_NAME; ?>
            </a>
            
            <button class="navbar-toggler" type="button" data-mdb-toggle="collapse" data-mdb-target="#navbarNav">
                <i class="fas fa-bars"></i>
            </button>
            
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto align-items-center">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="services.php">Services</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="portfolio.php">Portfolio</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="contact.php">Contact</a>
                    </li>
                    <?php if (isLoggedIn()): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="dashboard.php">Dashboard</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="logout.php">Logout</a>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="btn btn-primary btn-sm ms-2" href="login.php">Login</a>
                        </li>
                    <?php endif; ?>
                    <li class="nav-item ms-2">
                        <button class="btn btn-sm btn-outline-secondary" id="theme-toggle">
                            <i class="fas fa-moon"></i>
                        </button>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Page Header -->
    <div class="page-header">
        <div class="container">
            <h1 class="fw-bold mb-2">Our Services</h1>
            <p class="lead mb-0">Professional audio and video production services tailored to your needs</p>
        </div>
    </div>

    <!-- Main Content -->
    <div class="container my-5">
        <!-- Filters -->
        <div class="filter-section">
            <form method="GET" action="" class="row g-3">
                <div class="col-md-4">
                    <div class="form-outline">
                        <input type="text" name="search" class="form-control" value="<?php echo htmlspecialchars($search); ?>">
                        <label class="form-label">Search Services</label>
                    </div>
                </div>
                
                <div class="col-md-3">
                    <select name="category" class="form-select">
                        <option value="">All Categories</option>
                        <?php while ($cat = $categories_result->fetch_assoc()): ?>
                            <option value="<?php echo $cat['category']; ?>" <?php echo $category === $cat['category'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($cat['category']); ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                
                <div class="col-md-3">
                    <select name="price" class="form-select">
                        <option value="">All Prices</option>
                        <option value="low" <?php echo $price_range === 'low' ? 'selected' : ''; ?>>Under ₹5,000</option>
                        <option value="medium" <?php echo $price_range === 'medium' ? 'selected' : ''; ?>>₹5,000 - ₹15,000</option>
                        <option value="high" <?php echo $price_range === 'high' ? 'selected' : ''; ?>>Above ₹15,000</option>
                    </select>
                </div>
                
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-filter me-2"></i>Filter
                    </button>
                </div>
            </form>
        </div>

        <!-- Services Grid -->
        <div class="row">
            <?php if ($services_result && $services_result->num_rows > 0): ?>
                <?php while ($service = $services_result->fetch_assoc()): ?>
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="card service-card h-100">
                        <?php if ($service['image']): ?>
                            <img src="<?php echo htmlspecialchars($service['image']); ?>" class="card-img-top" alt="<?php echo htmlspecialchars($service['title']); ?>">
                        <?php else: ?>
                            <div class="card-img-top bg-primary text-white d-flex align-items-center justify-content-center" style="height: 200px;">
                                <i class="fas fa-headphones fa-4x"></i>
                            </div>
                        <?php endif; ?>
                        
                        <div class="card-body d-flex flex-column">
                            <div class="mb-2">
                                <span class="badge bg-primary"><?php echo htmlspecialchars($service['category']); ?></span>
                            </div>
                            <h5 class="card-title fw-bold"><?php echo htmlspecialchars($service['title']); ?></h5>
                            <p class="card-text text-muted flex-grow-1"><?php echo htmlspecialchars($service['short_description']); ?></p>
                            
                            <div class="mt-auto">
                                <div class="d-flex justify-content-between align-items-center mb-3">
                                    <span class="text-muted"><?php echo ucfirst(str_replace('_', ' ', $service['price_model'])); ?></span>
                                    <span class="h5 mb-0 text-primary">₹<?php echo number_format($service['base_price'], 0); ?>+</span>
                                </div>
                                <a href="service-detail.php?slug=<?php echo $service['slug']; ?>" class="btn btn-primary w-100">
                                    View Details <i class="fas fa-arrow-right ms-2"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div class="col-12 text-center py-5">
                    <i class="fas fa-search fa-4x text-muted mb-3"></i>
                    <h3>No services found</h3>
                    <p class="text-muted">Try adjusting your filters</p>
                    <a href="services.php" class="btn btn-primary">Clear Filters</a>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Mobile Bottom Navigation -->
    <div class="mobile-bottom-nav">
        <div class="container-fluid">
            <div class="row">
                <div class="col-3">
                    <a href="index.php" class="mobile-nav-item d-block">
                        <i class="fas fa-home"></i>
                        <div>Home</div>
                    </a>
                </div>
                <div class="col-3">
                    <a href="services.php" class="mobile-nav-item active d-block">
                        <i class="fas fa-th-large"></i>
                        <div>Services</div>
                    </a>
                </div>
                <div class="col-3">
                    <a href="<?php echo isLoggedIn() ? 'my-projects.php' : 'login.php'; ?>" class="mobile-nav-item d-block">
                        <i class="fas fa-folder"></i>
                        <div>Projects</div>
                    </a>
                </div>
                <div class="col-3">
                    <a href="<?php echo isLoggedIn() ? 'profile.php' : 'login.php'; ?>" class="mobile-nav-item d-block">
                        <i class="fas fa-user"></i>
                        <div>Profile</div>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.4.2/mdb.min.js"></script>
    <script>
        // Theme toggle
        const themeToggle = document.getElementById('theme-toggle');
        const htmlElement = document.documentElement;
        const savedTheme = localStorage.getItem('theme') || 'light';
        htmlElement.setAttribute('data-mdb-theme', savedTheme);
        updateThemeIcon(savedTheme);
        
        themeToggle.addEventListener('click', () => {
            const currentTheme = htmlElement.getAttribute('data-mdb-theme');
            const newTheme = currentTheme === 'light' ? 'dark' : 'light';
            htmlElement.setAttribute('data-mdb-theme', newTheme);
            localStorage.setItem('theme', newTheme);
            updateThemeIcon(newTheme);
        });
        
        function updateThemeIcon(theme) {
            const icon = themeToggle.querySelector('i');
            icon.className = theme === 'light' ? 'fas fa-moon' : 'fas fa-sun';
        }
    </script>
</body>
</html>
